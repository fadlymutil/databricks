# Databricks notebook source
# DBTITLE 1,Cell 1
# MAGIC %md
# MAGIC # Automated Test Runner — Single Course
# MAGIC
# MAGIC Creates a **single multi-task Lakeflow Job** for one course, with optional QA checks,
# MAGIC so the full run is visible in one timeline.
# MAGIC
# MAGIC **Run structure:**
# MAGIC - Course notebooks run in the dependency order you define in `COURSE_TASKS`.
# MAGIC - **QA Content Checker** can run independently (no dependencies) alongside the course tasks.
# MAGIC - The separate **Course-specific inputs** cell makes it easy to reuse this notebook for another course.
# MAGIC
# MAGIC ```
# MAGIC  QA Check      :  qa_content_checker  (optional, parallel)
# MAGIC  Course Tasks  :  task_01  ──►  task_02  ──►  task_03
# MAGIC ```
# MAGIC
# MAGIC **What it does**
# MAGIC 1. Reads course-specific settings from a dedicated configuration cell (`COURSE_NAME`, `LAB_NOTEBOOKS`, `COURSE_TASKS`).
# MAGIC 2. Auto-fills all `<FILL_IN>` placeholders in the configured lab notebooks using the inline solution blocks.
# MAGIC 3. Resolves all notebook paths relative to this notebook's location.
# MAGIC 4. Creates (or re-creates) a single persistent Lakeflow Job for the configured course.
# MAGIC 5. Optionally adds `qa_content_checker` as an **independent task** (no dependencies).
# MAGIC 6. Triggers the job with `jobs.run_now` and polls until completion.
# MAGIC 7. Appends one result row per task to a generic results table.
# MAGIC 8. Displays a combined summary table with clickable `run_page_url` links.
# MAGIC 9. Creates and publishes a **Lakeview dashboard** from the run results and QA findings.
# MAGIC 10. Raises if any task failed — triggering Lakeflow Job failure email.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# DBTITLE 1,Course-specific inputs
# MAGIC %md
# MAGIC ## Course-specific inputs

# COMMAND ----------

# DBTITLE 1,Configure course inputs
# Change the course name as per your course name
COURSE_NAME = "Get Started with Databricks for Data Warehousing"
RUN_QA_CHECKER = True
QA_TASK_RELATIVE_PATH = "./qa_content_checker"
QA_TASK_NAME = "QA Content Checker — Grammar, Deprecated, UI Steps"

# Tester emails — notified on job failure and success. Add as many as you like with comma seperated emails
TESTER_EMAILS = [
    "gourav.prajapati@databricks.com"
]

# Lab notebook paths for the auto-fill step (fills <FILL_IN> placeholders before a run).
# Left EMPTY for this course on purpose: this runner executes the classroom SETUP files
# (see COURSE_TASKS), not the demo/lab notebooks, because the demos/labs are UI-driven and
# cannot be validated by a headless job. There is nothing to auto-fill for a run we don't
# perform. If the labs are ever run as tasks, list their paths here.
LAB_NOTEBOOKS = []

# ── Compute Type Registry ─────────────────────────────────────────────────────
# Define all compute configurations available to tasks in this course.
# Each key becomes the compute_type value you assign to a task in COURSE_TASKS.
# Cell 14 reads these entries to create the correct compute resource per task.
#
# Supported "type" values:
#   "serverless"      – Databricks Serverless. Requires: environment_version (str)
#   "classic_cluster" – Existing all-purpose cluster. Requires: cluster_id (str)
#   "new_cluster"     – New cluster per run. Requires: cluster_config (dict)
#                       Keys map directly to ClusterSpec fields:
#                       spark_version, node_type_id, num_workers, etc.
#
# Tasks that omit compute_type fall back to DEFAULT_COMPUTE_TYPE.
# ─────────────────────────────────────────────────────────────────────────────

DEFAULT_COMPUTE_TYPE = "serverless_v5"

COMPUTE_TYPES = {
    "serverless_v5": {
        "type": "serverless",
        "environment_version": "5",
    },
    # ── SQL Warehouse ─────────────────────────────────────────────────────────
    # Use for notebooks that require a SQL warehouse (e.g. SQL Scripting,
    # Stored Procedures). The job will find an existing warehouse by name or
    # create one automatically using the config below.
    # Only PRO / Serverless warehouses are supported — not Classic.
    "shared_warehouse": {
        "type": "warehouse",
        "warehouse_name": "shared_warehouse",
        "cluster_size": "2X-Small",
        "warehouse_type": "PRO",
        "auto_stop_mins": 30,
    },
    # "serverless_v4": {
    #     "type": "serverless",
    #     "environment_version": "4",
    # },
    # "my_classic_cluster": {
    #     "type": "classic_cluster",
    #     "cluster_id": "<your-cluster-id>",
    # },
    # "new_standard_cluster": {
    #     "type": "new_cluster",
    #     "cluster_config": {
    #         "spark_version": "15.4.x-scala2.12",
    #         "node_type_id":  "i3.xlarge",
    #         "num_workers":   2,
    #     },
    # },
}

# Define the course notebook DAG here so this can be used for job scheduling as per your course.
#
# WHAT THIS RUNNER TESTS FOR THIS COURSE (important — HYBRID model):
#   This course splits into two kinds of content, verified by inspecting each notebook:
#
#   1. DEMOS (01, 02, 04, 06, 08, 10) — run the DEMO NOTEBOOK itself.
#      These contain real, pre-written SQL (SELECT / SHOW / DESCRIBE HISTORY / OPTIMIZE /
#      star-schema builds / MEASURE queries) that executes end to end. Each demo self-
#      provisions by running its own `%run ./Includes/Classroom-Setup-NN` at the top, so
#      running the demo also exercises its setup. Testing these validates real functionality.
#      (Demos 02 and 08 contain one "run what Genie generated" cell, but it is a self-contained
#      no-op with no downstream cell depending on it, so the notebook still runs clean.)
#
#   2. LABS (03, 05, 07, 09, 11) — run the CLASSROOM SETUP file only.
#      This is a "Genie Code" course: the lab answer cells are intentionally EMPTY except for a
#      `-- Use Genie Code (Cmd/Ctrl + I) ...` comment; the learner generates the SQL
#      interactively. There is no <FILL_IN> and no stored solution to auto-fill, so those cells
#      run as no-ops AND later cells depend on objects the learner was meant to create (e.g.
#      lab 11's `SELECT ... FROM vw_store_metrics` needs a view an empty Genie cell should have
#      created). Running the lab notebook headlessly would therefore FAIL on those downstream
#      cells. So we test the lab's Classroom-Setup instead — the testable, code-only part.
#
#   The setup files are pure code: each runs `%run ./Classroom-Setup-Common` (provisions the
#   per-user catalog + `vintage_audio` schema, creates a data volume, stages the course CSVs)
#   and `%run ./state_helpers` (ensure_* functions), then calls the ensure_* it needs
#   (ensure_source_dimensions / ensure_orders_bronze_full / ensure_star_schema /
#   ensure_metric_view_product). Auto Loader ingestion uses trigger(availableNow) — finite,
#   does not hang.
#
# Dependency rationale:
#   • Tasks are chained sequentially in course order with run_if=ALL_DONE. Ordering is not
#     strictly required for correctness (each demo's setup and each ensure_* self-provisions),
#     but everything writes into the SAME per-user `vintage_audio` schema and data volume, so
#     serializing avoids write races on shared tables/checkpoints and gives a clean run where
#     one failure does not skip the rest.
#   • All tasks run on Serverless (manifest: supported_dbrs = Serverless).
#   • The UI-only "00 - Course Overview", "AGENDA", and "Summary and Next Steps" are excluded.
COURSE_TASKS = [
    {
        "task_key": "demo_01",
        "name": "01 Demo - Databricks Workspace Walkthrough",
        "relative_path": "../Get Started with Databricks for Data Warehousing/01 Demo - Databricks Workspace Walkthrough",
        "depends_on": [],
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "demo_02",
        "name": "02 Demo - Querying the Vintage Audio Warehouse",
        "relative_path": "../Get Started with Databricks for Data Warehousing/02 Demo - Querying the Vintage Audio Warehouse",
        "depends_on": ["demo_01"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "lab_03_setup",
        "name": "Classroom-Setup-03 (for 03 Lab - Explore the Vintage Audio Tables) — lab is Genie-driven, testing setup only",
        "relative_path": "../Get Started with Databricks for Data Warehousing/Includes/Classroom-Setup-03",
        "depends_on": ["demo_02"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "demo_04",
        "name": "04 Demo - Tuning Delta Tables for Analytical Queries",
        "relative_path": "../Get Started with Databricks for Data Warehousing/04 Demo - Tuning Delta Tables for Analytical Queries",
        "depends_on": ["lab_03_setup"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "lab_05_setup",
        "name": "Classroom-Setup-05 (for 05 Lab - Optimize the Products Table) — lab is Genie-driven, testing setup only",
        "relative_path": "../Get Started with Databricks for Data Warehousing/Includes/Classroom-Setup-05",
        "depends_on": ["demo_04"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "demo_06",
        "name": "06 Demo - Loading Data into the Warehouse",
        "relative_path": "../Get Started with Databricks for Data Warehousing/06 Demo - Loading Data into the Warehouse",
        "depends_on": ["lab_05_setup"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "lab_07_setup",
        "name": "Classroom-Setup-07 (for 07 Lab - Incrementally Load New Orders) — lab is Genie-driven, testing setup only",
        "relative_path": "../Get Started with Databricks for Data Warehousing/Includes/Classroom-Setup-07",
        "depends_on": ["demo_06"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "demo_08",
        "name": "08 Demo - Building a Star Schema",
        "relative_path": "../Get Started with Databricks for Data Warehousing/08 Demo - Building a Star Schema",
        "depends_on": ["lab_07_setup"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "lab_09_setup",
        "name": "Classroom-Setup-09 (for 09 Lab - Build a Store Dimension) — lab is Genie-driven, testing setup only",
        "relative_path": "../Get Started with Databricks for Data Warehousing/Includes/Classroom-Setup-09",
        "depends_on": ["demo_08"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "demo_10",
        "name": "10 Demo - Deliver Insights with Metric Views",
        "relative_path": "../Get Started with Databricks for Data Warehousing/10 Demo - Deliver Insights with Metric Views",
        "depends_on": ["lab_09_setup"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
    {
        "task_key": "lab_11_setup",
        "name": "Classroom-Setup-11 (for 11 Lab - Create a Metric View for Store Performance) — lab is Genie-driven, testing setup only",
        "relative_path": "../Get Started with Databricks for Data Warehousing/Includes/Classroom-Setup-11",
        "depends_on": ["demo_10"],
        "run_if": "ALL_DONE",
        "compute_type": "serverless_v5",
    },
]

# COMMAND ----------

# DBTITLE 1,Utility — wrap / restore failing SQL cells at runtime
# ─────────────────────────────────────────────────────────────────────────────
# Utility: wrap_failing_sql_cell / restore_sql_cell
#
# Purpose
# -------
# Some demo notebooks contain SQL cells that are *intentionally designed to fail*
# (e.g. to demonstrate BEGIN...END halting behaviour). When those notebooks run
# as job tasks the cell failure stops the entire notebook, skipping all
# subsequent cells (cleanup, further demos, etc.).
#
# These helpers let the course tester temporarily wrap any such cell with an
# outer BEGIN...DECLARE EXIT HANDLER...END block — pure SQL, no language change
# — so the notebook continues past the intentional failure. After the job
# completes the original source is restored so students always see the clean
# demo notebook.
#
# How to use
# ----------
# 1. Before job creation / run:
#       restores = patch_notebooks_for_job(CELLS_TO_PATCH)
#
# 2. After job completes (pass/fail):
#       restore_notebooks_after_job(restores)
#
# CELLS_TO_PATCH is a list of dicts defined in the cell that follows this one.
# Each entry:
#   {
#       "notebook_path" : absolute workspace path to the notebook,
#       "cell_nuid"     : nuid of the SQL cell to wrap,
#       "handler_message": (optional) text returned by the handler SELECT,
#   }
# ─────────────────────────────────────────────────────────────────────────────

import base64, json, os
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ExportFormat, ImportFormat

_sdk_client = None

def _get_client(w=None):
    """Returns a WorkspaceClient, reusing a module-level instance if available."""
    if w:
        return w
    global _sdk_client
    if _sdk_client is None:
        _sdk_client = WorkspaceClient()
    return _sdk_client


def wrap_failing_sql_cell(
    notebook_path: str,
    cell_nuid: str,
    handler_message: str = None,
    w=None,
) -> str:
    """
    Wraps a SQL cell's BEGIN...END block with an outer DECLARE EXIT HANDLER
    so the notebook continues executing even if the inner block fails.
    The cell stays SQL — no language change.

    Args:
        notebook_path   : Absolute workspace path to the target notebook.
        cell_nuid       : nuid of the SQL cell to wrap.
        handler_message : Optional message shown as a result row when the
                          exception is caught.
        w               : WorkspaceClient to reuse (optional).
    Returns:
        original_source (str) — pass this to restore_sql_cell() to undo.
    """
    _w  = _get_client(w)
    msg = handler_message or (
        "[Expected failure] The inner BEGIN...END block failed as designed. "
        "Notebook continues."
    )

    # --- export
    export  = _w.workspace.export(path=notebook_path, format=ExportFormat.JUPYTER)
    nb      = json.loads(base64.b64decode(export.content))

    original_source = None
    for cell in nb.get("cells", []):
        if cell.get("metadata", {}).get("nuid", "") == cell_nuid:
            original_source = (
                "".join(cell["source"])
                if isinstance(cell["source"], list)
                else cell["source"]
            )
            indented = "\n".join("  " + line for line in original_source.splitlines())
            cell["source"] = (
                "-- Outer block catches the expected error; inner block is unchanged.\n"
                "BEGIN\n"
                "  DECLARE EXIT HANDLER FOR SQLEXCEPTION\n"
                f"    SELECT '{msg}' AS message;\n\n"
                "  BEGIN\n"
                f"{indented}\n"
                "  END;\n"
                "END;"
            )
            break

    if original_source is None:
        raise ValueError(f"Cell nuid='{cell_nuid}' not found in: {notebook_path}")

    # --- re-import
    encoded = base64.b64encode(json.dumps(nb).encode()).decode()
    _w.workspace.import_(
        path=notebook_path,
        format=ImportFormat.JUPYTER,
        overwrite=True,
        content=encoded,
    )
    print(f"  ✅ Wrapped  : {notebook_path.split('/')[-1]}  (nuid: {cell_nuid[:8]}...)")
    return original_source


def restore_sql_cell(
    notebook_path: str,
    cell_nuid: str,
    original_source: str,
    w=None,
):
    """
    Restores a cell to its original source. Reverses wrap_failing_sql_cell().

    Args:
        notebook_path  : Absolute workspace path to the target notebook.
        cell_nuid      : nuid of the cell to restore.
        original_source: The string returned by wrap_failing_sql_cell().
        w              : WorkspaceClient to reuse (optional).
    """
    _w     = _get_client(w)
    export = _w.workspace.export(path=notebook_path, format=ExportFormat.JUPYTER)
    nb     = json.loads(base64.b64decode(export.content))

    for cell in nb.get("cells", []):
        if cell.get("metadata", {}).get("nuid", "") == cell_nuid:
            cell["source"] = original_source
            break

    encoded = base64.b64encode(json.dumps(nb).encode()).decode()
    _w.workspace.import_(
        path=notebook_path,
        format=ImportFormat.JUPYTER,
        overwrite=True,
        content=encoded,
    )
    print(f"  ✅ Restored : {notebook_path.split('/')[-1]}  (nuid: {cell_nuid[:8]}...)")


def patch_notebooks_for_job(patches: list, w=None) -> list:
    """
    Wraps all cells listed in `patches` before a job run.
    Returns a restore-list to pass to restore_notebooks_after_job().

    Args:
        patches : list of dicts, each with keys:
                    notebook_path (str)       — absolute workspace path
                    cell_nuid     (str)       — nuid of the failing cell
                    handler_message (str, opt)— custom handler message
        w       : WorkspaceClient to reuse (optional).
    Returns:
        restores (list) — same dicts with 'original_source' added.
    """
    print("\n═" * 36 + "\nPATCHING NOTEBOOKS FOR JOB RUN\n" + "═" * 36)
    restores = []
    for p in patches:
        original = wrap_failing_sql_cell(
            notebook_path   = p["notebook_path"],
            cell_nuid       = p["cell_nuid"],
            handler_message = p.get("handler_message"),
            w               = w,
        )
        restores.append({**p, "original_source": original})
    print(f"  {len(restores)} cell(s) patched.\n")
    return restores


def restore_notebooks_after_job(restores: list, w=None):
    """
    Restores all cells patched by patch_notebooks_for_job().

    Args:
        restores : the list returned by patch_notebooks_for_job().
        w        : WorkspaceClient to reuse (optional).
    """
    print("\n═" * 36 + "\nRESTORING NOTEBOOKS AFTER JOB RUN\n" + "═" * 36)
    for r in restores:
        restore_sql_cell(r["notebook_path"], r["cell_nuid"], r["original_source"], w=w)
    print(f"  {len(restores)} cell(s) restored.\n")


print("✅ Utility functions loaded: wrap_failing_sql_cell, restore_sql_cell,"
      " patch_notebooks_for_job, restore_notebooks_after_job")

# COMMAND ----------

# DBTITLE 1,Replace the FILL_IN in lab notebooks
# ── Auto-Fill Lab Notebooks ──────────────────────────────────────────────────
# This script finds all <FILL_IN> placeholders in lab notebooks and replaces
# them with solution code extracted from the nearby solution blocks.
#
# HOW IT WORKS:
# 1. Exports each lab notebook as .ipynb JSON
# 2. Scans code cells for <FILL_IN> markers
# 3. Looks ahead in subsequent markdown cells for <code>...</code> blocks
# 4. Extracts the solution and replaces the original cell source
# 5. Re-imports the patched notebook
#
# Safe to re-run: it only patches cells that still contain <FILL_IN>.
# ──────────────────────────────────────────────────────────────────────────────

import base64
import json
import os
import re
import html as html_lib
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.workspace import ExportFormat, ImportFormat, Language

w = WorkspaceClient()

# Derive course_root from this notebook's own path
_nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
course_root = "/".join(_nb_path.split("/")[:-1])

# LAB_NOTEBOOKS is configured in the course-specific inputs cell above.
# Resolve to absolute workspace paths
lab_abs_paths = [os.path.normpath(f"{course_root}/{p}") for p in LAB_NOTEBOOKS]


def extract_solution_from_source(source: str) -> str | None:
    """Extract code from a Databricks solution cell.

    Handles:
    - Fenced code blocks: ```python\\n...\\n``` (used in current labs)
    - HTML <code> tags: <code>...</code> (legacy fallback)
    - Strips %md / %md-sandbox magic prefixes before parsing.
    """
    # Strip Databricks magic prefix (%md, %md-sandbox, etc.)
    clean = re.sub(r'^%md[a-zA-Z-]*[ \t]*\n', '', source.lstrip(), count=1)

    # 1. Fenced code block (most common in current labs)
    match = re.search(r'```(?:python|sql|scala|r|sh)?\s*\n(.*?)\n[ \t]*```', clean, re.DOTALL)
    if match:
        code = match.group(1)
        lines = code.split('\n')
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()
        return '\n'.join(lines) if lines else None

    # 2. HTML <code> tags (fallback for older lab format)
    match = re.search(r'<code[^>]*>\s*\n?(.*?)\n?\s*</code>', clean, re.DOTALL)
    if match:
        code = html_lib.unescape(match.group(1))
        lines = code.split('\n')
        while lines and not lines[0].strip():
            lines.pop(0)
        while lines and not lines[-1].strip():
            lines.pop()
        return '\n'.join(lines) if lines else None

    return None


def is_solution_candidate(cell: dict) -> bool:
    """Return True if a cell is a potential answer/solution block.

    In Databricks ipynb exports, %md-sandbox cells are stored as code cells
    (not markdown), so we must check both cell_type=='markdown' and code cells
    that start with a %md magic prefix.
    """
    source = ''.join(cell.get("source", []))
    has_code_block = '```' in source or '<code>' in source
    is_markdown_type = cell.get("cell_type") == "markdown"
    is_md_magic = cell.get("cell_type") == "code" and bool(re.match(r'\s*%md', source))
    return (is_markdown_type or is_md_magic) and has_code_block


def fill_notebook(notebook_path: str) -> dict:
    """Fill all <FILL_IN> cells in a single notebook. Returns stats."""
    stats = {"path": notebook_path, "blanks_found": 0, "filled": 0, "no_answer": 0}

    # Export notebook as ipynb
    export_resp = w.workspace.export(path=notebook_path, format=ExportFormat.JUPYTER)
    nb_json = json.loads(base64.b64decode(export_resp.content))
    cells = nb_json.get("cells", [])

    for i, cell in enumerate(cells):
        source = ''.join(cell.get("source", []))

        # Check if this cell has FILL_IN markers
        if '<FILL_IN>' not in source and '<FILL IN>' not in source and '--FILL IN--' not in source:
            continue

        # Skip markdown cells (we only fill code cells)
        if cell.get("cell_type") != "code":
            continue

        stats["blanks_found"] += 1

        # Look ahead up to 5 cells for a solution block.
        # %md-sandbox solution cells may appear as 'code' type in ipynb exports,
        # so is_solution_candidate() checks both cell_type and %md magic prefix.
        solution = None
        for j in range(i + 1, min(i + 6, len(cells))):
            next_cell = cells[j]
            next_source = ''.join(next_cell.get("source", []))
            if is_solution_candidate(next_cell):
                solution = extract_solution_from_source(next_source)
                if solution:
                    break
            # Stop looking once we hit a real (non-magic) code cell
            elif next_cell.get("cell_type") == "code" and not re.match(r'\s*%', next_source):
                break

        if solution:
            # Check if solution has %sql magic — if so, handle cell language
            if solution.strip().startswith('%sql'):
                # Remove %sql prefix, keep the SQL code
                solution_lines = solution.strip().split('\n')
                # Keep %sql as first line for the cell magic
                cell["source"] = [solution + '\n']
            else:
                cell["source"] = [solution + '\n']
            stats["filled"] += 1
        else:
            stats["no_answer"] += 1
            print(f"  ⚠️  NO ANSWER FOUND for cell {i} in {notebook_path}")

    # Re-import the patched notebook
    if stats["filled"] > 0:
        patched_content = base64.b64encode(json.dumps(nb_json).encode()).decode()
        w.workspace.import_(
            path=notebook_path,
            content=patched_content,
            format=ImportFormat.JUPYTER,
            overwrite=True,
            language=Language.PYTHON,
        )

    return stats


# ── Run the filler ────────────────────────────────────────────────────────────
print("═" * 70)
print("AUTO-FILL LAB NOTEBOOKS")
print("═" * 70)

all_stats = []
for path in lab_abs_paths:
    print(f"\n▶ Processing: {path.split('/')[-1]}")
    try:
        s = fill_notebook(path)
        all_stats.append(s)
        print(f"   Blanks found: {s['blanks_found']}  |  Filled: {s['filled']}  |  No answer: {s['no_answer']}")
    except Exception as e:
        print(f"   ❌ ERROR: {e}")
        all_stats.append({"path": path, "blanks_found": 0, "filled": 0, "no_answer": 0, "error": str(e)})

# ── Summary ───────────────────────────────────────────────────────────────────
print("\n" + "═" * 70)
total_blanks = sum(s["blanks_found"] for s in all_stats)
total_filled = sum(s["filled"] for s in all_stats)
total_no_ans = sum(s["no_answer"] for s in all_stats)
print(f"TOTAL:  {total_blanks} blanks found  |  {total_filled} filled  |  {total_no_ans} blockers")
print("═" * 70)

# COMMAND ----------

# DBTITLE 1,Creating table for writing the report
# Catalog / schema / table names
# Derive catalog from the current user's login — each lab user owns a UC catalog
# named after the username portion of their email (dots/hyphens replaced with underscores).
_current_user     = spark.sql("SELECT current_user()").collect()[0][0]
_username         = _current_user.split("@")[0].replace(".", "_").replace("-", "_")

RESULTS_CATALOG   = _username   # e.g. labuser15507750_1782991657
RESULTS_SCHEMA    = "default"   # "default" schema is pre-created in every UC catalog
RESULTS_TABLE     = "notebook_run_results"
QA_FINDINGS_TABLE = "qa_content_findings"

# How long to wait for the entire job run (seconds)
TOTAL_RUN_TIMEOUT_SECONDS = 60 * 60 * 2   # 2 hour ceiling
POLL_INTERVAL_SECONDS     = 15

# Job and dashboard names
JOB_NAME       = f"[Course Validation] {COURSE_NAME}"
DASHBOARD_NAME = f"[Course Validation] {COURSE_NAME} Results Dashboard"

# Build the task list from the reusable course configuration above.
TASKS = []

if RUN_QA_CHECKER:
    TASKS.append({
        "task_key": "qa_content_checker",
        "course": "QA",
        "name": QA_TASK_NAME,
        "relative_path": QA_TASK_RELATIVE_PATH,
        "depends_on": [],
        "compute_type": DEFAULT_COMPUTE_TYPE,
    })

for task in COURSE_TASKS:
    TASKS.append({
        "task_key": task["task_key"],
        "course": COURSE_NAME,
        "name": task["name"],
        "relative_path": task["relative_path"],
        "depends_on": task.get("depends_on", []),
        "compute_type": task.get("compute_type", DEFAULT_COMPUTE_TYPE),
    })

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports and workspace client

# COMMAND ----------

# DBTITLE 1,Cell 8
import json
import os
import time
from datetime import datetime, timezone

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.compute import ClusterSpec, Environment
from databricks.sdk.service.jobs import (
    JobEmailNotifications,
    JobEnvironment,
    NotebookTask,
    RunIf,
    RunLifeCycleState,
    RunResultState,
    Task,
    TaskDependency,
)

from pyspark.sql import Row
from pyspark.sql.types import (
    DoubleType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

w = WorkspaceClient()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Resolve workspace paths

# COMMAND ----------

this_notebook_path = (
    dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
)
course_root = "/".join(this_notebook_path.split("/")[:-1])

for t in TASKS:
    # os.path.normpath resolves '../' so Databricks gets a clean absolute path
    t["notebook_path"] = os.path.normpath(f"{course_root}/{t['relative_path']}")

print(f"Course root: {course_root}\n")
for t in TASKS:
    print(f"  [{t['task_key']}]  {t['name']}\n      {t['notebook_path']}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ensure results table exists

# COMMAND ----------

# DBTITLE 1,Cell 12
results_fqn = f"{RESULTS_CATALOG}.{RESULTS_SCHEMA}.{RESULTS_TABLE}"

# Ensure catalog and schema exist before writing tables
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {RESULTS_CATALOG}.{RESULTS_SCHEMA}")
print(f"Using catalog/schema: {RESULTS_CATALOG}.{RESULTS_SCHEMA}")

results_schema = StructType([
    StructField("run_timestamp",    TimestampType(), nullable=False),
    StructField("job_id",           LongType(),      nullable=True),
    StructField("job_run_id",       LongType(),      nullable=True),
    StructField("course",           StringType(),    nullable=True),
    StructField("task_key",         StringType(),    nullable=False),
    StructField("demo_name",        StringType(),    nullable=False),
    StructField("notebook_path",    StringType(),    nullable=False),
    StructField("status",           StringType(),    nullable=False),  # PASS / FAIL / TIMEOUT
    StructField("result_state",     StringType(),    nullable=True),
    StructField("life_cycle_state", StringType(),    nullable=True),
    StructField("duration_seconds", DoubleType(),    nullable=True),
    StructField("run_id",           LongType(),      nullable=True),
    StructField("run_page_url",     StringType(),    nullable=True),
    StructField("error_message",    StringType(),    nullable=True),
])

if not spark.catalog.tableExists(results_fqn):
    spark.createDataFrame([], results_schema).write.format("delta").saveAsTable(results_fqn)
    print(f"Created results table: {results_fqn}")
else:
    print(f"Results table exists: {results_fqn}")

# COMMAND ----------

# DBTITLE 1,Optional stop — run setup only (set RUN_SETUP_ONLY = True to stop here)
# ── Optional early exit ──────────────────────────────────────────────────────
# Set RUN_SETUP_ONLY = True to run only the setup/config half (cells 1–12).
# Leave it False (or just run all cells) to continue with job creation & execution.
# ─────────────────────────────────────────────────────────────────────────────
RUN_SETUP_ONLY = False

if RUN_SETUP_ONLY:
    print("Setup complete. Stopping here — set RUN_SETUP_ONLY = False to continue with job creation.")
    dbutils.notebook.exit("Setup-only run complete.")

# COMMAND ----------

# DBTITLE 1,Cell 12
# MAGIC %md
# MAGIC ## Create (or re-create) the course Lakeflow Job

# COMMAND ----------

# DBTITLE 1,Cell 14
# Delete any existing job with the same name so we always get a clean definition.

existing = [j for j in w.jobs.list(name=JOB_NAME)]
for j in existing:
    w.jobs.delete(job_id=j.job_id)
    print(f"Deleted existing job: {j.job_id} ({j.settings.name})")

# Build Task objects — compute resource determined per task via compute_type.
job_tasks = []
_warehouse_id_cache: dict = {}  # avoid repeated warehouse API calls for same warehouse
for t in TASKS:
    compute_key  = t.get("compute_type", DEFAULT_COMPUTE_TYPE)
    compute_cfg  = COMPUTE_TYPES[compute_key]
    compute_kind = compute_cfg["type"]

    task_kwargs = dict(
        task_key=t["task_key"],
        description=t["name"],
        notebook_task=NotebookTask(notebook_path=t["notebook_path"]),
        depends_on=[TaskDependency(task_key=dep) for dep in t["depends_on"]],
        run_if=RunIf[t["run_if"]] if t.get("run_if") else None,
    )

    if compute_kind == "serverless":
        # compute_type key doubles as environment_key; tasks sharing the same
        # compute_type will reference the same JobEnvironment spec below.
        task_kwargs["environment_key"] = compute_key
    elif compute_kind == "classic_cluster":
        task_kwargs["existing_cluster_id"] = compute_cfg["cluster_id"]
    elif compute_kind == "new_cluster":
        task_kwargs["new_cluster"] = ClusterSpec(**compute_cfg["cluster_config"])
    elif compute_kind == "warehouse":
        from databricks.sdk.service.sql import CreateWarehouseRequestWarehouseType as _WarehouseType
        wh_name = compute_cfg["warehouse_name"]
        if wh_name not in _warehouse_id_cache:
            # Find existing warehouse by name, or create one
            wh_id = next((wh.id for wh in w.warehouses.list() if wh.name == wh_name), None)
            if wh_id is None:
                wh_type = _WarehouseType[compute_cfg.get("warehouse_type", "PRO").upper()]
                new_wh = w.warehouses.create(
                    name=wh_name,
                    cluster_size=compute_cfg.get("cluster_size", "2X-Small"),
                    warehouse_type=wh_type,
                    auto_stop_mins=int(compute_cfg.get("auto_stop_mins", 30)),
                )
                wh_id = new_wh.id
                print(f"  Created warehouse '{wh_name}': {wh_id}")
            else:
                print(f"  Found existing warehouse '{wh_name}': {wh_id}")
            _warehouse_id_cache[wh_name] = wh_id
        # Override notebook_task with warehouse_id — no cluster spec on Task
        task_kwargs["notebook_task"] = NotebookTask(
            notebook_path=t["notebook_path"],
            warehouse_id=_warehouse_id_cache[wh_name],
        )
    else:
        raise ValueError(f"Unknown compute type '{compute_kind}' for task '{t['task_key']}'")

    job_tasks.append(Task(**task_kwargs))

# Build one JobEnvironment per unique serverless compute_type actually used by tasks.
used_compute_keys = {t.get("compute_type", DEFAULT_COMPUTE_TYPE) for t in TASKS}
job_environments = [
    JobEnvironment(
        environment_key=ck,
        spec=Environment(environment_version=COMPUTE_TYPES[ck]["environment_version"]),
    )
    for ck in sorted(used_compute_keys)
    if COMPUTE_TYPES[ck]["type"] == "serverless"
]

created_job = w.jobs.create(
    name=JOB_NAME,
    tasks=job_tasks,
    environments=job_environments or None,
    email_notifications=JobEmailNotifications(
        on_failure=TESTER_EMAILS,
        on_success=TESTER_EMAILS,
    ),
)
job_id = created_job.job_id
print(f"Created Lakeflow Job: {job_id}  ({JOB_NAME})")
print(f"\nTask DAG:")
for t in TASKS:
    ct   = t.get("compute_type", DEFAULT_COMPUTE_TYPE)
    deps = " → depends on: " + ", ".join(t["depends_on"]) if t["depends_on"] else " (starts immediately)"
    print(f"  {t['task_key']}  [compute: {ct}]{deps}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Trigger the job run and poll until all tasks complete

# COMMAND ----------

run_response  = w.jobs.run_now(job_id=job_id)
job_run_id    = run_response.run_id
run_timestamp = datetime.now(timezone.utc)

print(f"Triggered job run: {job_run_id}")
print(f"Polling every {POLL_INTERVAL_SECONDS}s (timeout={TOTAL_RUN_TIMEOUT_SECONDS}s)...\n")

deadline        = time.time() + TOTAL_RUN_TIMEOUT_SECONDS
final_run       = None
terminal_states = {RunLifeCycleState.TERMINATED, RunLifeCycleState.SKIPPED, RunLifeCycleState.INTERNAL_ERROR}

while time.time() < deadline:
    run = w.jobs.get_run(run_id=job_run_id)
    lc  = run.state.life_cycle_state if run.state else None

    task_states = {
        tk.task_key: (
            tk.state.life_cycle_state.value if tk.state and tk.state.life_cycle_state else "PENDING"
        )
        for tk in (run.tasks or [])
    }
    print(f"  [{datetime.now(timezone.utc).strftime('%H:%M:%S')}] run={lc}  tasks={task_states}")

    if lc in terminal_states:
        final_run = run
        break

    time.sleep(POLL_INTERVAL_SECONDS)
else:
    print("TIMEOUT — cancelling the run.")
    try:
        w.jobs.cancel_run(run_id=job_run_id)
    except Exception:
        pass
    final_run = w.jobs.get_run(run_id=job_run_id)

print(f"\nFinal run state: {final_run.state.life_cycle_state if final_run.state else 'UNKNOWN'}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Collect per-task results

# COMMAND ----------

task_cfg = {t["task_key"]: t for t in TASKS}

results = []
for task_run in (final_run.tasks or []):
    cfg   = task_cfg.get(task_run.task_key, {})
    state = task_run.state

    result_state = state.result_state.value     if state and state.result_state     else None
    life_cycle   = state.life_cycle_state.value  if state and state.life_cycle_state  else None
    error_msg    = state.state_message           if state                             else None

    duration = None
    if task_run.start_time and task_run.end_time:
        duration = float((task_run.end_time - task_run.start_time) / 1000.0)

    if life_cycle == RunLifeCycleState.TERMINATED.value and result_state == RunResultState.SUCCESS.value:
        status = "PASS"
    elif life_cycle in (RunLifeCycleState.SKIPPED.value, RunLifeCycleState.INTERNAL_ERROR.value):
        status = "FAIL"
    elif life_cycle == RunLifeCycleState.TERMINATED.value:
        status = "FAIL"
    else:
        status = "TIMEOUT"

    results.append({
        "job_id":           job_id,
        "job_run_id":       job_run_id,
        "course":           cfg.get("course", ""),
        "task_key":         task_run.task_key,
        "demo_name":        cfg.get("name", task_run.task_key),
        "notebook_path":    cfg.get("notebook_path", ""),
        "status":           status,
        "result_state":     result_state,
        "life_cycle_state": life_cycle,
        "duration_seconds": duration,
        "run_id":           task_run.run_id,
        "run_page_url":     task_run.run_page_url,
        "error_message":    error_msg,
    })

# Sort back into configured TASKS order
order = {t["task_key"]: i for i, t in enumerate(TASKS)}
results.sort(key=lambda r: order.get(r["task_key"], 999))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Append results to Delta + display summary

# COMMAND ----------

# DBTITLE 1,Cell 18
rows       = [Row(run_timestamp=run_timestamp, **r) for r in results]
results_df = spark.createDataFrame(rows, schema=results_schema)

results_df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(results_fqn)

print(f"Appended {results_df.count()} rows to {results_fqn}\n")

# Summary for the configured single-course run
summary_groups = [COURSE_NAME]
if RUN_QA_CHECKER:
    summary_groups.append("QA")

for group_name in summary_groups:
    group_results = [r for r in results if r["course"] == group_name]
    if not group_results:
        continue

    passed = sum(1 for r in group_results if r["status"] == "PASS")
    failed = sum(1 for r in group_results if r["status"] != "PASS")
    icon = "✅" if failed == 0 else "❌"
    label = "QA Checks" if group_name == "QA" else COURSE_NAME
    print(f"  {icon} {label}:  {passed}/{len(group_results)} passed")

print(f"\nOverall: {sum(1 for r in results if r['status'] == 'PASS')}/{len(results)} tasks passed")

display(results_df)

# COMMAND ----------

# DBTITLE 1,Section: Create Lakeview Dashboard
# MAGIC %md
# MAGIC ## Create Lakeview Dashboard

# COMMAND ----------

# DBTITLE 1,Create and publish Lakeview dashboard
import json
from databricks.sdk.service.dashboards import Dashboard

# ── Dashboard Configuration ────────────────────────────────────────────────────
DASHBOARD_FOLDER = "/".join(this_notebook_path.split("/")[:-2])  # Up from CourseRunner/
qa_findings_fqn = f"{RESULTS_CATALOG}.{RESULTS_SCHEMA}.{QA_FINDINGS_TABLE}"
course_label_sql = COURSE_NAME.replace("'", "''")

# ── Dataset SQL (always filters to the latest run) ────────────────────────────
run_filter = f"job_run_id = (SELECT MAX(job_run_id) FROM {results_fqn})"
qa_filter  = f"run_timestamp = (SELECT MAX(run_timestamp) FROM {qa_findings_fqn})"

status_summary_sql = (
    f"SELECT status, COUNT(*) AS task_count "
    f"FROM {results_fqn} WHERE {run_filter} "
    f"GROUP BY status ORDER BY status"
)

task_detail_sql = (
    f"SELECT CASE WHEN course = 'QA' THEN 'QA Checks' ELSE '{course_label_sql}' END AS run_group, "
    f"task_key, demo_name, status, ROUND(duration_seconds, 1) AS duration_seconds, "
    f"run_page_url, error_message "
    f"FROM {results_fqn} WHERE {run_filter} "
    f"ORDER BY CASE WHEN course = 'QA' THEN 0 ELSE 1 END, task_key"
)

qa_sev_sql = (
    f"SELECT severity, COUNT(*) AS issue_count "
    f"FROM {qa_findings_fqn} WHERE {qa_filter} "
    f"GROUP BY severity ORDER BY issue_count DESC"
) if spark.catalog.tableExists(qa_findings_fqn) else (
    "SELECT 'No Data' AS severity, 0 AS issue_count WHERE 1=0"
)

qa_detail_sql = (
    f"SELECT notebook_name, cell_index, issue_type, severity, "
    f"offending_text, suggested_fix, check_source "
    f"FROM {qa_findings_fqn} WHERE {qa_filter} "
    f"ORDER BY severity, notebook_name, cell_index"
) if spark.catalog.tableExists(qa_findings_fqn) else (
    "SELECT '' AS notebook_name, 0 AS cell_index, '' AS issue_type, "
    "'' AS severity, '' AS offending_text, '' AS suggested_fix, '' AS check_source WHERE 1=0"
)

datasets = [
    {
        "name": "ds_status_summary",
        "displayName": "Task Status Summary",
        "query": status_summary_sql,
    },
    {
        "name": "ds_task_detail",
        "displayName": "Task Results Detail",
        "query": task_detail_sql,
    },
]

pages = [
    {
        "name": "pg_runs",
        "displayName": f"{COURSE_NAME} Run Results",
        "layout": [
            {
                "widget": {
                    "name": "w_bar",
                    "title": "Task Status — Latest Run",
                    "description": "",
                    "queries": [{
                        "name": "main",
                        "query": {
                            "datasetName": "ds_status_summary",
                            "fields": [
                                {"name": "status", "expression": "`status`"},
                                {"name": "task_count", "expression": "`task_count`"}
                            ],
                            "disaggregated": True
                        }
                    }],
                    "spec": {
                        "version": 2,
                        "widgetType": "bar",
                        "encodings": {
                            "x": {"fieldName": "status", "displayName": "Status"},
                            "y": {"fieldName": "task_count", "displayName": "Tasks"},
                            "color": {"fieldName": "status", "displayName": "Status"}
                        }
                    }
                },
                "position": {"x": 0, "y": 0, "width": 6, "height": 6}
            },
            {
                "widget": {
                    "name": "w_task_table",
                    "title": "Task Results — Latest Run",
                    "description": "",
                    "queries": [{
                        "name": "main",
                        "query": {
                            "datasetName": "ds_task_detail",
                            "fields": [
                                {"name": "run_group", "expression": "`run_group`"},
                                {"name": "task_key", "expression": "`task_key`"},
                                {"name": "demo_name", "expression": "`demo_name`"},
                                {"name": "status", "expression": "`status`"},
                                {"name": "duration_seconds", "expression": "`duration_seconds`"},
                                {"name": "run_page_url", "expression": "`run_page_url`"},
                                {"name": "error_message", "expression": "`error_message`"}
                            ],
                            "disaggregated": True
                        }
                    }],
                    "spec": {
                        "version": 2,
                        "widgetType": "table",
                        "encodings": {
                            "columns": [
                                {"fieldName": "run_group", "visible": True, "title": "Run Group"},
                                {"fieldName": "task_key", "visible": True, "title": "Task Key"},
                                {"fieldName": "demo_name", "visible": True, "title": "Task Name"},
                                {"fieldName": "status", "visible": True, "title": "Status"},
                                {"fieldName": "duration_seconds", "visible": True, "title": "Duration (s)"},
                                {"fieldName": "run_page_url", "visible": True, "title": "Run URL"},
                                {"fieldName": "error_message", "visible": True, "title": "Error"}
                            ]
                        }
                    }
                },
                "position": {"x": 0, "y": 6, "width": 12, "height": 8}
            }
        ]
    }
]

if RUN_QA_CHECKER:
    datasets.extend([
        {
            "name": "ds_qa_severity",
            "displayName": "QA Issues by Severity",
            "query": qa_sev_sql,
        },
        {
            "name": "ds_qa_detail",
            "displayName": "QA Findings Detail",
            "query": qa_detail_sql,
        },
    ])

    pages.append({
        "name": "pg_qa",
        "displayName": "QA Findings",
        "layout": [
            {
                "widget": {
                    "name": "w_qa_bar",
                    "title": "QA Issues by Severity — Latest Run",
                    "description": "",
                    "queries": [{
                        "name": "main",
                        "query": {
                            "datasetName": "ds_qa_severity",
                            "fields": [
                                {"name": "severity", "expression": "`severity`"},
                                {"name": "issue_count", "expression": "`issue_count`"}
                            ],
                            "disaggregated": True
                        }
                    }],
                    "spec": {
                        "version": 2,
                        "widgetType": "bar",
                        "encodings": {
                            "x": {"fieldName": "severity", "displayName": "Severity"},
                            "y": {"fieldName": "issue_count", "displayName": "Issue Count"}
                        }
                    }
                },
                "position": {"x": 0, "y": 0, "width": 6, "height": 6}
            },
            {
                "widget": {
                    "name": "w_qa_table",
                    "title": "QA Findings Detail — Latest Run",
                    "description": "",
                    "queries": [{
                        "name": "main",
                        "query": {
                            "datasetName": "ds_qa_detail",
                            "fields": [
                                {"name": "notebook_name", "expression": "`notebook_name`"},
                                {"name": "cell_index", "expression": "`cell_index`"},
                                {"name": "issue_type", "expression": "`issue_type`"},
                                {"name": "severity", "expression": "`severity`"},
                                {"name": "offending_text", "expression": "`offending_text`"},
                                {"name": "suggested_fix", "expression": "`suggested_fix`"},
                                {"name": "check_source", "expression": "`check_source`"}
                            ],
                            "disaggregated": True
                        }
                    }],
                    "spec": {
                        "version": 2,
                        "widgetType": "table",
                        "encodings": {
                            "columns": [
                                {"fieldName": "notebook_name", "visible": True, "title": "Notebook"},
                                {"fieldName": "cell_index", "visible": True, "title": "Cell #"},
                                {"fieldName": "issue_type", "visible": True, "title": "Issue Type"},
                                {"fieldName": "severity", "visible": True, "title": "Severity"},
                                {"fieldName": "offending_text", "visible": True, "title": "Offending Text"},
                                {"fieldName": "suggested_fix", "visible": True, "title": "Suggested Fix"},
                                {"fieldName": "check_source", "visible": True, "title": "Source"}
                            ]
                        }
                    }
                },
                "position": {"x": 0, "y": 6, "width": 12, "height": 8}
            }
        ]
    })

spec = {
    "datasets": datasets,
    "pages": pages,
}

# ── Create / re-create the Lakeview Dashboard ─────────────────────────────────
try:
    for d in w.lakeview.list():
        if d.display_name == DASHBOARD_NAME:
            w.lakeview.trash(dashboard_id=d.dashboard_id)
            print(f"Replaced existing dashboard: {d.dashboard_id}")
            break
except Exception:
    pass  # No existing dashboard — proceed to create

dashboard = w.lakeview.create(Dashboard(
    display_name=DASHBOARD_NAME,
    serialized_dashboard=json.dumps(spec),
    parent_path=DASHBOARD_FOLDER,
))
w.lakeview.publish(dashboard_id=dashboard.dashboard_id)

workspace_host = spark.conf.get("spark.databricks.workspaceUrl")
dashboard_url  = f"https://{workspace_host}/dashboardsv3/{dashboard.dashboard_id}"

print(f"✅  Lakeview Dashboard created & published!")
print(f"    Name : {DASHBOARD_NAME}")
print(f"    ID   : {dashboard.dashboard_id}")
print(f"    URL  : {dashboard_url}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Fail the notebook if any task failed

# COMMAND ----------

failed = [r for r in results if r["status"] != "PASS"]
if failed:
    summary = "\n".join(
        f"  - [{r['task_key']}] {r['demo_name']}: {r['status']} ({r['result_state']}) — {r['run_page_url']}"
        for r in failed
    )
    raise RuntimeError(
        f"{len(failed)} of {len(results)} task(s) failed on Serverless v{ENVIRONMENT_VERSION}:\n{summary}"
    )

print(f"All {len(results)} tasks passed on Serverless v{ENVIRONMENT_VERSION}.")
dbutils.notebook.exit(json.dumps({
    "total":  len(results),
    "passed": len(results),
    "failed": 0,
}))