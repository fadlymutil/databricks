# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC
# MAGIC <div style="background: #1B5162; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lesson 02</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Querying the Vintage Audio Warehouse</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Discover the lesson tables in Catalog Explorer, write your first SQL queries against governed Unity Catalog tables, and turn the results into a visualization, all from a single notebook.</div>
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema so your queries run against the correct context.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-02

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1100px; margin: 0 auto; font-family: sans-serif;">
# MAGIC
# MAGIC <div style="font-size: 20pt; font-weight: 700; color: #0b2026; margin-bottom: 6px;">What a Warehousing Practitioner Does</div>
# MAGIC <div style="font-size: 13pt; color: #5A6F77; margin-bottom: 24px;">Day-to-day warehousing work breaks into three phases. Each one is traditionally slowed down by data living in too many places and tools being scattered across the stack. Databricks brings data, compute, modeling, and BI delivery into a single governed environment.</div>
# MAGIC
# MAGIC <div style="display: flex; justify-content: center; align-items: stretch; gap: 24px; flex-wrap: wrap;">
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 220px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 24px; text-align: center; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #4299E0; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Discover &amp; Load</div>
# MAGIC     <div style="font-size: 13pt; color: #5E7077;">Find or land the data the business depends on, often arriving as files or pulled from operational systems.</div>
# MAGIC   </div>
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 220px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 24px; text-align: center; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #FE3722; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Model &amp; Tune</div>
# MAGIC     <div style="font-size: 13pt; color: #5E7077;">Shape the data into a model the business can reason about (typically dimensions and facts), and tune for fast analytical reads.</div>
# MAGIC   </div>
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 220px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; justify-content: center; gap: 10px; padding: 24px; text-align: center; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #00A972; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Deliver &amp; Tune</div>
# MAGIC     <div style="font-size: 13pt; color: #5E7077;">Get the right metrics to stakeholders through dashboards, queries, and BI tools, and keep them fast as data grows.</div>
# MAGIC   </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Where data lives: the three-level namespace
# MAGIC
# MAGIC Every table in Databricks lives at a **three-level address**: `catalog.schema.table`. Catalogs are the top-level container, schemas group related tables inside a catalog, and tables hold the data itself. Volumes (used for files) also live inside a schema. The diagram below shows the layout you have in your workspace right now, after running the setup script.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="width: 100%; max-width: 920px; margin: 0 auto;">
# MAGIC <svg viewBox="0 0 920 436" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" style="width: 100%; height: auto; display: block;">
# MAGIC   <text x="460" y="28" text-anchor="middle" fill="#1B5162" font-size="20" font-weight="700" letter-spacing="1.5">THE THREE-LEVEL NAMESPACE</text>
# MAGIC   <!-- Metastore container -->
# MAGIC   <rect x="16" y="44" width="888" height="240" rx="10" fill="#F9F7F4" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC   <text x="36" y="70" fill="#1B5162" font-size="16" font-weight="700" letter-spacing="1.5">METASTORE</text>
# MAGIC   <!-- Catalog container -->
# MAGIC   <rect x="36" y="82" width="848" height="190" rx="8" fill="#FFFFFF" stroke="#FE3722" stroke-width="2"/>
# MAGIC   <!-- Catalog info (left of schema) -->
# MAGIC   <text x="56" y="140" fill="#FE3722" font-size="16" font-weight="700" letter-spacing="1.5">CATALOG</text>
# MAGIC   <text x="56" y="168" fill="#0b2026" font-size="18" font-weight="700">labuser_yourname</text>
# MAGIC   <text x="56" y="192" fill="#5E7077" font-size="16" font-style="italic">your personal</text>
# MAGIC   <text x="56" y="212" fill="#5E7077" font-size="16" font-style="italic">catalog</text>
# MAGIC   <!-- Schema box (right of catalog info) -->
# MAGIC   <rect x="230" y="98" width="636" height="160" rx="8" fill="#F9F7F4" stroke="#FE3722" stroke-width="2"/>
# MAGIC   <text x="250" y="124" fill="#FE3722" font-size="16" font-weight="700" letter-spacing="1.5">SCHEMA</text>
# MAGIC   <text x="250" y="148" fill="#0b2026" font-size="18" font-weight="700">vintage_audio</text>
# MAGIC   <!-- Tables -->
# MAGIC   <rect x="250" y="162" width="192" height="48" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="346" y="183" text-anchor="middle" fill="#0b2026" font-size="16" font-weight="700">customers</text>
# MAGIC   <text x="346" y="201" text-anchor="middle" fill="#5E7077" font-size="16">TABLE</text>
# MAGIC   <rect x="452" y="162" width="192" height="48" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="548" y="183" text-anchor="middle" fill="#0b2026" font-size="16" font-weight="700">products</text>
# MAGIC   <text x="548" y="201" text-anchor="middle" fill="#5E7077" font-size="16">TABLE</text>
# MAGIC   <rect x="654" y="162" width="192" height="48" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="750" y="183" text-anchor="middle" fill="#0b2026" font-size="16" font-weight="700">stores</text>
# MAGIC   <text x="750" y="201" text-anchor="middle" fill="#5E7077" font-size="16">TABLE</text>
# MAGIC   <!-- Volume -->
# MAGIC   <rect x="250" y="220" width="596" height="24" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.2" stroke-dasharray="4,3"/>
# MAGIC   <text x="548" y="237" text-anchor="middle" fill="#5E7077" font-size="16"><tspan font-weight="700" fill="#0b2026">data</tspan>  &#8212;  VOLUME (CSV files staged for Lesson 06)</text>
# MAGIC   <!-- Full table address callout -->
# MAGIC   <rect x="16" y="308" width="888" height="120" rx="10" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC   <text x="36" y="334" fill="#1B5162" font-size="16" font-weight="700" letter-spacing="1.5">FULL TABLE ADDRESS</text>
# MAGIC   <!-- Color-coded address segments -->
# MAGIC   <rect x="34" y="346" width="167" height="24" rx="3" fill="#FFF0EF"/>
# MAGIC   <rect x="211" y="346" width="137" height="24" rx="3" fill="#FFF5ED"/>
# MAGIC   <rect x="358" y="346" width="94" height="24" rx="3" fill="#EDF5F7"/>
# MAGIC   <text x="36" y="364" font-size="17" font-family="monospace" font-weight="700"><tspan fill="#FE3722">labuser_yourname</tspan><tspan fill="#5E7077">.</tspan><tspan fill="#FF8C42">vintage_audio</tspan><tspan fill="#5E7077">.</tspan><tspan fill="#1B5162">customers</tspan></text>
# MAGIC   <text x="36" y="388" fill="#FE3722" font-size="16" font-family="monospace">&#8593; catalog</text>
# MAGIC   <text x="206" y="388" fill="#FF8C42" font-size="16" font-family="monospace">&#8593; schema</text>
# MAGIC   <text x="351" y="388" fill="#1B5162" font-size="16" font-family="monospace">&#8593; table</text>
# MAGIC   <text x="36" y="416" fill="#5E7077" font-size="16" font-style="italic">After setup runs, USE CATALOG and USE SCHEMA are set, so you can refer to tables by short name (e.g. customers).</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Confirm where you are
# MAGIC
# MAGIC The cell below confirms what catalog and schema your session is pointing at right now.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT current_catalog(), current_schema();

# COMMAND ----------

# MAGIC %md
# MAGIC You should see your personal catalog (something like `labuser_yourname`) and the `vintage_audio` schema. Every query in this notebook will run against that schema unless you say otherwise.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. List the tables in this schema
# MAGIC
# MAGIC The `SHOW TABLES` command lists every table in the current schema. Run it to see what was created for you by the setup script.

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see three tables: **`customers`**, **`products`**, and **`stores`**. These are the three dimension sources for Vintage Audio Co.
# MAGIC
# MAGIC The order data has not been loaded into a table yet. Its CSV files are sitting in the `data` volume, waiting for Lesson 06 to load them.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 3. Inspect a table with DESCRIBE EXTENDED
# MAGIC
# MAGIC Before querying a table for the first time, it's useful to see its full schema and where the data physically lives. `DESCRIBE EXTENDED` returns columns, data types, storage location, format, and other table metadata.
# MAGIC
# MAGIC <div style="max-width: 880px; margin: 20px auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="font-size: 15px; color: #5E7077; margin-bottom: 14px;">The output has three sections separated by blank rows:</div>
# MAGIC   <div style="display: flex; gap: 14px; align-items: stretch;">
# MAGIC     <!-- Part 1: Columns -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">1</span>
# MAGIC         Column Schema
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Names + data types</strong></div>
# MAGIC         <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 10px; font-family: monospace; font-size: 14px; line-height: 1.7; color: #1B3139;">
# MAGIC           customer_id&nbsp;&nbsp;&nbsp;&nbsp;string<br/>
# MAGIC           customer_name&nbsp;&nbsp;string<br/>
# MAGIC           city&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;string<br/>
# MAGIC           postal_code&nbsp;&nbsp;&nbsp;&nbsp;int<br/>
# MAGIC           <span style="color: #5E7077;">... 6 more columns</span>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Part 2: Delta Statistics -->
# MAGIC     <div style="flex: 1; border: 2px solid #FF8C42; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #FF8C42; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">2</span>
# MAGIC         Delta Statistics
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #FFFAF6; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Min/max stats for file skipping</strong></div>
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="background: #fff; border: 1px solid #E8D5C4; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Method</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">first-32</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #E8D5C4; border-radius: 6px; padding: 8px 10px; font-size: 14px; color: #3d5a65; line-height: 1.5;">
# MAGIC             <strong>Tracked columns</strong><br/>
# MAGIC             <span style="font-family: monospace;">customer_id, customer_name, email, city, state, postal_code, ...</span>
# MAGIC           </div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Part 3: Table Info -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px;">3</span>
# MAGIC         Table Metadata
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1;">
# MAGIC         <div style="font-size: 15px; color: #3d5a65; margin-bottom: 10px;"><strong>Location, format, size</strong></div>
# MAGIC         <div style="display: flex; flex-direction: column; gap: 6px;">
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Provider</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">delta</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Type</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">MANAGED</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Location</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">s3://...</span>
# MAGIC           </div>
# MAGIC           <div style="background: #fff; border: 1px solid #DCE0E2; border-radius: 6px; padding: 8px 10px; font-size: 15px; display: flex; justify-content: space-between;">
# MAGIC             <span style="color: #5E7077;">Statistics</span><span style="font-weight: 700; color: #1B3139; font-family: monospace; font-size: 14px;">5,000 rows</span>
# MAGIC           </div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE EXTENDED customers;

# COMMAND ----------

# MAGIC %md
# MAGIC Reading the result from top to bottom, it has three parts:
# MAGIC
# MAGIC 1. **Column names and data types** : one row per column (`customer_id`, `customer_name`, `email`, `address`, `city`, `state`, and so on), each with its data type.
# MAGIC 2. **Delta statistics columns** : a short block listing the columns Delta collects statistics on, which it uses to skip data it doesn't need to read.
# MAGIC 3. **Detailed table information** : table-level metadata, including the storage `Location` (a path under your catalog's managed storage) and the `Provider` (which will be `delta`).
# MAGIC
# MAGIC A blank separator row sits between each part. None of the course tables are partitioned, so the `Partition Information` is empty. (Partitioning is one performance lever, but not always the best one. Lesson 04 covers a more effective lever for analytical workloads: Z-order clustering.)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Your first query: select a few rows
# MAGIC
# MAGIC `SELECT * FROM <table> LIMIT 10` is a quick way to see what's actually in a table. Run it for `customers`.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM customers LIMIT 10;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see 10 rows. Each customer has a `customer_id`, a name, an email and phone, a US address, a `customer_since_date`, and a `loyalty_tier` (one of `Bronze`, `Silver`, `Gold`, `Platinum`).

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 5. Filter and aggregate: customers by state
# MAGIC
# MAGIC Analytical SQL is usually about **aggregating** (counting, summing, averaging) **grouped by** some dimension. The query below groups customers by their home state and counts them.
# MAGIC
# MAGIC <div style="width: 100%; margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 16px;">
# MAGIC   <div style="display: flex; gap: 16px; align-items: center;">
# MAGIC     <!-- Step 1: Raw rows -->
# MAGIC     <div style="flex: 0 0 auto;">
# MAGIC       <div style="font-size: 16px; font-weight: 700; color: #1B5162; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; text-align: center;">customers table</div>
# MAGIC       <div style="background: #fff; border: 1.5px solid #DCE0E2; border-radius: 8px; overflow: hidden;">
# MAGIC         <div style="display: grid; grid-template-columns: auto 1fr; font-size: 16px;">
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 1px solid #DCE0E2; border-right: 1px solid #DCE0E2;">name</div>
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 1px solid #DCE0E2;">state</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #3d5a65;">Alice</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; font-weight: 600; color: #1B5162; background: #EDF5F7;">CA</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #3d5a65;">Bob</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; font-weight: 600; color: #FF8C42; background: #FFF5ED;">TX</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #3d5a65;">Carol</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; font-weight: 600; color: #1B5162; background: #EDF5F7;">CA</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #3d5a65;">Dan</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; font-weight: 600; color: #1B5162; background: #EDF5F7;">CA</div>
# MAGIC           <div style="padding: 7px 14px; border-right: 1px solid #eee; color: #3d5a65;">Eve</div>
# MAGIC           <div style="padding: 7px 14px; font-weight: 600; color: #FF8C42; background: #FFF5ED;">TX</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC       <div style="text-align: center; font-size: 15px; color: #5E7077; margin-top: 6px;">5,000 rows</div>
# MAGIC     </div>
# MAGIC     <!-- Arrow 1 -->
# MAGIC     <div style="flex: 0 0 auto; text-align: center; padding: 0 8px;">
# MAGIC       <div style="font-size: 16px; color: #5E7077; font-weight: 600; margin-bottom: 4px;">GROUP BY<br/>state</div>
# MAGIC       <div style="font-size: 28px; color: #1B5162;">&#x2192;</div>
# MAGIC     </div>
# MAGIC     <!-- Step 2: Grouped -->
# MAGIC     <div style="flex: 0 0 auto;">
# MAGIC       <div style="font-size: 16px; font-weight: 700; color: #1B5162; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; text-align: center;">Grouped buckets</div>
# MAGIC       <div style="display: flex; flex-direction: column; gap: 10px;">
# MAGIC         <div style="background: #EDF5F7; border: 1.5px solid #1B5162; border-radius: 8px; padding: 12px 20px; text-align: center;">
# MAGIC           <div style="font-size: 17px; font-weight: 700; color: #1B5162;">CA</div>
# MAGIC           <div style="font-size: 15px; color: #5E7077;">Alice, Carol, Dan</div>
# MAGIC         </div>
# MAGIC         <div style="background: #FFF5ED; border: 1.5px solid #FF8C42; border-radius: 8px; padding: 12px 20px; text-align: center;">
# MAGIC           <div style="font-size: 17px; font-weight: 700; color: #FF8C42;">TX</div>
# MAGIC           <div style="font-size: 15px; color: #5E7077;">Bob, Eve</div>
# MAGIC         </div>
# MAGIC         <div style="background: #f4f6f7; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 10px 20px; text-align: center;">
# MAGIC           <div style="font-size: 15px; color: #5E7077;">... more states</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Arrow 2 -->
# MAGIC     <div style="flex: 0 0 auto; text-align: center; padding: 0 8px;">
# MAGIC       <div style="font-size: 16px; color: #5E7077; font-weight: 600; margin-bottom: 4px;">COUNT(*)</div>
# MAGIC       <div style="font-size: 28px; color: #1B5162;">&#x2192;</div>
# MAGIC     </div>
# MAGIC     <!-- Step 3: Result -->
# MAGIC     <div style="flex: 1;">
# MAGIC       <div style="font-size: 16px; font-weight: 700; color: #1B5162; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; text-align: center;">Result</div>
# MAGIC       <div style="background: #fff; border: 1.5px solid #DCE0E2; border-radius: 8px; overflow: hidden;">
# MAGIC         <div style="display: grid; grid-template-columns: 1fr 1fr; font-size: 16px;">
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 1px solid #DCE0E2; border-right: 1px solid #DCE0E2;">state</div>
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 1px solid #DCE0E2;">customer_count</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #1B5162;">CA</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; color: #1B3139; font-weight: 700;">3</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #FF8C42;">TX</div>
# MAGIC           <div style="padding: 7px 14px; border-bottom: 1px solid #eee; color: #1B3139; font-weight: 700;">2</div>
# MAGIC           <div style="padding: 7px 14px; border-right: 1px solid #eee; color: #5E7077;">...</div>
# MAGIC           <div style="padding: 7px 14px; color: #5E7077;">...</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC       <div style="text-align: center; font-size: 14px; color: #5E7077; margin-top: 6px;">One row per state, sorted DESC, top 15</div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   state,
# MAGIC   COUNT(*) AS customer_count
# MAGIC FROM customers
# MAGIC GROUP BY state
# MAGIC ORDER BY customer_count DESC
# MAGIC LIMIT 15;

# COMMAND ----------

# MAGIC %md
# MAGIC The result is one row per state, sorted by `customer_count` descending. The top states tend to be the populous ones (California, Texas, Florida), which is what you would expect from a US retailer.

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Combine two tables with a join
# MAGIC
# MAGIC So far every query has read from a single table. A **join** lets one query pull columns from two tables at once. Most joins match rows using a shared key, for example pairing each order with the customer who placed it. You will work with those key-based joins once the `orders` fact table exists in Lesson 08.
# MAGIC
# MAGIC There is one join that needs no matching key: a **cross join**. A cross join pairs *every* row in the first table with *every* row in the second, so the result has one row for each possible combination. The diagram below shows the idea with a tiny example.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="width: 100%; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="text-align: center; font-size: 18px; font-weight: 700; color: #1B5162; margin-bottom: 16px;">CROSS JOIN: every row paired with every row</div>
# MAGIC   <div style="display: flex; gap: 16px; align-items: flex-start;">
# MAGIC     <!-- Left: source tables -->
# MAGIC     <div style="display: flex; gap: 10px; align-items: flex-start; flex: 0 0 auto;">
# MAGIC       <!-- Tiers column -->
# MAGIC       <div>
# MAGIC         <div style="font-size: 15px; font-weight: 700; color: #FE3722; text-align: center; margin-bottom: 6px;">tiers</div>
# MAGIC         <div style="background: #fff; border: 2px solid #FE3722; border-radius: 8px; padding: 12px 20px; text-align: center; font-size: 16px; color: #0b2026; margin-bottom: 6px;">Gold</div>
# MAGIC         <div style="background: #fff; border: 2px solid #FE3722; border-radius: 8px; padding: 12px 20px; text-align: center; font-size: 16px; color: #0b2026;">Platinum</div>
# MAGIC       </div>
# MAGIC       <!-- X symbol -->
# MAGIC       <div style="padding-top: 36px; font-size: 22px; font-weight: 700; color: #1B5162;">&#215;</div>
# MAGIC       <!-- Categories column -->
# MAGIC       <div>
# MAGIC         <div style="font-size: 15px; font-weight: 700; color: #00A972; text-align: center; margin-bottom: 6px;">categories</div>
# MAGIC         <div style="background: #fff; border: 2px solid #00A972; border-radius: 8px; padding: 12px 20px; text-align: center; font-size: 16px; color: #0b2026; margin-bottom: 6px;">Speakers</div>
# MAGIC         <div style="background: #fff; border: 2px solid #00A972; border-radius: 8px; padding: 12px 20px; text-align: center; font-size: 16px; color: #0b2026; margin-bottom: 6px;">Amplifiers</div>
# MAGIC         <div style="background: #fff; border: 2px solid #00A972; border-radius: 8px; padding: 12px 20px; text-align: center; font-size: 16px; color: #0b2026;">Turntables</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Arrow -->
# MAGIC     <div style="padding-top: 60px; font-size: 28px; color: #1B5162;">&#8594;</div>
# MAGIC     <!-- Right: result as a proper table -->
# MAGIC     <div style="flex: 1;">
# MAGIC       <div style="font-size: 15px; font-weight: 700; color: #1B5162; margin-bottom: 6px;">result: 2 &#215; 3 = 6 rows (with actual counts from the query)</div>
# MAGIC       <div style="background: #fff; border: 2px solid #1B5162; border-radius: 8px; overflow: hidden;">
# MAGIC         <div style="display: grid; grid-template-columns: auto auto auto; font-size: 15px;">
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 2px solid #DCE0E2; border-right: 1px solid #DCE0E2;">loyalty_tier</div>
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 2px solid #DCE0E2; border-right: 1px solid #DCE0E2;">category</div>
# MAGIC           <div style="padding: 8px 14px; font-weight: 700; color: #5E7077; background: #f4f6f7; border-bottom: 2px solid #DCE0E2; text-align: right;">row_count</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #FE3722; background: #FFF8F7;">Gold</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #1B3139; background: #FFF8F7;">Speakers</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; color: #1B3139; background: #FFF8F7; text-align: right; font-weight: 600;">21,455</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #FE3722; background: #FFF8F7;">Gold</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #1B3139; background: #FFF8F7;">Amplifiers</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; color: #1B3139; background: #FFF8F7; text-align: right; font-weight: 600;">24,520</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 2px solid #DCE0E2; border-right: 1px solid #eee; font-weight: 600; color: #FE3722; background: #FFF8F7;">Gold</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 2px solid #DCE0E2; border-right: 1px solid #eee; color: #1B3139; background: #FFF8F7;">Turntables</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 2px solid #DCE0E2; color: #1B3139; background: #FFF8F7; text-align: right; font-weight: 600;">36,780</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #FE3722;">Platinum</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #1B3139;">Speakers</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; color: #1B3139; text-align: right; font-weight: 600;">7,175</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-weight: 600; color: #FE3722;">Platinum</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; border-right: 1px solid #eee; color: #1B3139;">Amplifiers</div>
# MAGIC           <div style="padding: 8px 14px; border-bottom: 1px solid #eee; color: #1B3139; text-align: right; font-weight: 600;">8,200</div>
# MAGIC           <div style="padding: 8px 14px; border-right: 1px solid #eee; font-weight: 600; color: #FE3722;">Platinum</div>
# MAGIC           <div style="padding: 8px 14px; border-right: 1px solid #eee; color: #1B3139;">Turntables</div>
# MAGIC           <div style="padding: 8px 14px; color: #1B3139; text-align: right; font-weight: 600;">12,300</div>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Build this query with Genie Code (AI-assisted)
# MAGIC
# MAGIC Instead of typing the SQL by hand, describe what you want in plain language and let **Genie Code** write it. Genie Code is the natural-language code assistant built into the notebook.
# MAGIC
# MAGIC <div style="width: 100%; margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 16px;">
# MAGIC   <!-- 3-step flow -->
# MAGIC   <div style="display: flex; gap: 0; align-items: stretch;">
# MAGIC     <!-- Step 1: How to open -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 12px 16px; font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0;">1</span>
# MAGIC         Open Genie Code
# MAGIC       </div>
# MAGIC       <div style="padding: 16px; background: #f8fafc; flex: 1; color: #3d5a65; line-height: 1.6;">
# MAGIC         <div style="margin-bottom: 10px;"><strong>Inline:</strong> <code style="font-size: 16px; background: #EEEDE9; padding: 2px 8px; border-radius: 3px;">Cmd/Ctrl + I</code> inside a code cell</div>
# MAGIC         <div><strong>Sidebar:</strong> Click the <strong>Genie / Assistant</strong> icon in the right panel</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Arrow -->
# MAGIC     <div style="flex: 0 0 44px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #1B5162;">&#x2192;</div>
# MAGIC     <!-- Step 2: Describe -->
# MAGIC     <div style="flex: 1.6; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 12px 16px; font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0;">2</span>
# MAGIC         Paste this prompt
# MAGIC       </div>
# MAGIC       <div style="padding: 16px; background: #f8fafc; flex: 1;">
# MAGIC         <div id="genie-prompt-text" style="background: #fff; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 14px 16px; color: #3d5a65; line-height: 1.5; font-style: italic;">For Gold and Platinum customers only, pair every loyalty tier with every product category and count the combinations. Return loyalty_tier, category, and the count aliased as row_count, sorted by tier then count descending. Use the customers and products tables.</div>
# MAGIC         <button onclick="var t=document.getElementById('genie-prompt-text').textContent,a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.left='-9999px';document.body.appendChild(a);a.select();document.execCommand('copy');document.body.removeChild(a);this.textContent='Copied!';this.style.background='#00A972';this.style.borderColor='#00A972';var b=this;setTimeout(function(){b.textContent='Copy prompt';b.style.background='#1B5162';b.style.borderColor='#1B5162'},1500)" style="margin-top: 12px; background: #1B5162; color: #fff; border: 2px solid #1B5162; border-radius: 6px; padding: 8px 20px; font-size: 16px; font-weight: 600; cursor: pointer;">Copy prompt</button>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <!-- Arrow -->
# MAGIC     <div style="flex: 0 0 44px; display: flex; align-items: center; justify-content: center; font-size: 26px; color: #1B5162;">&#x2192;</div>
# MAGIC     <!-- Step 3: Review + Run -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 12px 16px; font-size: 17px; font-weight: 700; display: flex; align-items: center; gap: 10px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0;">3</span>
# MAGIC         Review and run
# MAGIC       </div>
# MAGIC       <div style="padding: 16px; background: #f8fafc; flex: 1; color: #3d5a65; line-height: 1.6;">
# MAGIC         <div style="margin-bottom: 10px;">Genie Code generates SQL with <code style="font-size: 16px; background: #EEEDE9; padding: 2px 8px; border-radius: 3px;">CROSS JOIN</code></div>
# MAGIC         <div>Review the output, run it, and compare against the reference below</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC Make sure the empty code cell below is the target, then paste the prompt from Step 2 into Genie Code.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Run the query Genie Code generated here.
# MAGIC -- If you'd rather check your result, the reference query is in the expandable section below.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the full cross-join query</strong></summary>
# MAGIC <pre><code>SELECT
# MAGIC   c.loyalty_tier,
# MAGIC   p.category,
# MAGIC   COUNT(*) AS row_count
# MAGIC FROM customers c
# MAGIC CROSS JOIN products p
# MAGIC WHERE c.loyalty_tier IN ('Gold', 'Platinum')
# MAGIC GROUP BY c.loyalty_tier, p.category
# MAGIC ORDER BY c.loyalty_tier, row_count DESC;</code></pre>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC This result is artificial: pairing every tier with every category isn't a business question anyone would ask. It exists to show the cross-join mechanic. In real warehouse work, the common pattern is joining a **fact table** to its dimensions on a matching key, which you'll build starting in Lesson 08.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 7. Turn a result into a visualization, inline
# MAGIC
# MAGIC Databricks notebook results can be turned into a chart without leaving the notebook or writing any visualization code. Run the query below, then turn the result into a bar chart.
# MAGIC
# MAGIC <div style="width: 100%; margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="display: flex; gap: 0; align-items: stretch;">
# MAGIC     <!-- Step 1 -->
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">1</span> Run query
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         Returns <strong>state</strong> + <strong>customer_count</strong> for the top 10
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <!-- Step 2 -->
# MAGIC     <div style="flex: 1.1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">2</span> Click +
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         Above the result table (next to the <strong>Table</strong> tab), click <strong>+</strong> and choose <strong>Visualization</strong>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <!-- Step 3 -->
# MAGIC     <div style="flex: 1.8; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">3</span> Visualization Editor settings
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #f8fafc; flex: 1; font-size: 15px; color: #3d5a65;">
# MAGIC         <div style="display: grid; grid-template-columns: auto auto; gap: 3px 12px; align-items: center;">
# MAGIC           <span style="font-weight: 700; color: #1B5162;">Type:</span><code style="font-size: 14px; background: #EEEDE9; padding: 1px 6px; border-radius: 3px;">Bar</code>
# MAGIC           <span style="font-weight: 700; color: #1B5162;">Horizontal chart:</span><span>&#9745; on</span>
# MAGIC           <span style="font-weight: 700; color: #1B5162;">Y column:</span><code style="font-size: 14px; background: #EEEDE9; padding: 1px 6px; border-radius: 3px;">state</code>
# MAGIC           <span style="font-weight: 700; color: #1B5162;">X columns:</span><code style="font-size: 14px; background: #EEEDE9; padding: 1px 6px; border-radius: 3px;">customer_count</code>
# MAGIC         </div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 30px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: #1B5162;">&#x2192;</div>
# MAGIC     <!-- Step 4 -->
# MAGIC     <div style="flex: 0.8; border: 2px solid #00A972; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #00A972; color: #fff; padding: 8px 12px; font-size: 15px; font-weight: 700; display: flex; align-items: center; gap: 6px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0;">4</span> Save
# MAGIC       </div>
# MAGIC       <div style="padding: 10px 12px; background: #F0FAF5; flex: 1; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         Chart embeds as a new tab, auto-refreshes
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   state,
# MAGIC   COUNT(*) AS customer_count
# MAGIC FROM customers
# MAGIC GROUP BY state
# MAGIC ORDER BY customer_count DESC
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %md
# MAGIC #### Make a bar chart from this result
# MAGIC
# MAGIC 1. Above the result table, click the **`+`** icon and choose **Visualization**.
# MAGIC 2. Set the **Visualization Type** to **`Bar`**.
# MAGIC 3. Assign the columns so that **`state`** labels the bars and **`customer_count`** sets their length:
# MAGIC    - If the editor shows a **Horizontal chart** toggle that is **on** by default, the axes are swapped: put **`customer_count`** on the **X column** and **`state`** on the **Y column**.
# MAGIC    - If **Horizontal chart** is **off** (vertical bars), put **`state`** on the **X column** and **`customer_count`** on the **Y column**.
# MAGIC
# MAGIC    Either way, you want each bar labeled by a state and sized by its customer count. If the chart looks wrong, the two columns are simply assigned to the wrong axes; swap them.
# MAGIC 4. Click **Save**.
# MAGIC
# MAGIC You now have a chart embedded in the notebook. It will refresh automatically if the underlying query result changes.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## What you did in this lesson
# MAGIC
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC
# MAGIC In this lesson you:
# MAGIC
# MAGIC - Located the course tables inside Unity Catalog using the three-level namespace.
# MAGIC - Ran `SHOW TABLES` and `DESCRIBE EXTENDED` to discover and inspect tables.
# MAGIC - Wrote `SELECT` queries with `WHERE`, `GROUP BY`, and `ORDER BY`.
# MAGIC - Learned what a join does and used Genie Code to build a `CROSS JOIN` query from a plain-language prompt.
# MAGIC - Turned a result set into an inline bar-chart visualization.
# MAGIC
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>