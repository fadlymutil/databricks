# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC
# MAGIC <div style="background: #02A36F; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lab</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Explore the Vintage Audio Tables</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Apply what you learned in Lesson 02 to the <code>products</code> and <code>stores</code> tables on your own.</div>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema so your queries run against the correct context.
# MAGIC

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-03

# COMMAND ----------

# MAGIC %md
# MAGIC **Context:** In Lesson 02 you queried the `customers` table to see who Vintage Audio Co.'s customers are and where they live, and you used **Genie Code** to build a query from a plain-language prompt. In this lab you'll keep using that AI-assisted approach to explore the **product catalog** and the **store footprint**.
# MAGIC
# MAGIC In this practice you will:
# MAGIC
# MAGIC 1. Preview the `products` table to see what columns it has.
# MAGIC 1. Count the products in each category.
# MAGIC 1. Find the five most expensive products.
# MAGIC 1. Compare two ways of counting stores and pick the correct one.
# MAGIC 1. Turn one of the results into a chart.
# MAGIC
# MAGIC **How to work through each task:** the default path is to open **Genie Code** and give it the prompt provided. Open it inline with **Cmd/Ctrl + I** inside the target cell, or open the full **Genie / Assistant** panel from the right sidebar. Run what it generates, then expand the reference block to compare. If you'd rather write the SQL yourself, go ahead, the reference is there either way.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 1: Preview the `products` table
# MAGIC
# MAGIC Before analyzing a table, look at what's actually in it. Get the **first 10 rows** of `products` so you can see the columns.
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_438_1').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_438_1" style="white-space:pre-wrap; overflow-wrap:break-word;">Show the first 10 rows of the products table.</code></pre>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Open Genie Code (Cmd/Ctrl + I) in this cell, paste the prompt above, and run what it generates.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the full preview query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb1').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb1">SELECT * FROM products LIMIT 10;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see 10 rows. The columns include `product_id`, `product_name`, `category`, `subcategory`, `brand`, `list_price`, `cost`, and `release_year`. These are the fields you will work with in the next tasks.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 2: Count products by category
# MAGIC
# MAGIC Find out how many products are in each `category`.
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_438_2').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_438_2" style="white-space:pre-wrap; overflow-wrap:break-word;">Count the number of products in each category. Return the category and the count aliased as product_count, sorted by product_count from highest to lowest.</code></pre>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above, then run the result.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the full count-by-category query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb2').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb2">SELECT
# MAGIC   category,
# MAGIC   COUNT(*) AS product_count
# MAGIC FROM products
# MAGIC GROUP BY category
# MAGIC ORDER BY product_count DESC;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see five rows. **Accessories** is the largest category (90 products), followed by **Turntables** (60), **Amplifiers** (40), **Speakers** (35), and **Cassette Decks** (25). This shape reflects the real audio retail mix: accessories sell in many variants, while the high-ticket categories have fewer SKUs.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Task 3: Find the five most expensive products
# MAGIC
# MAGIC Find the five products with the highest `list_price`, and show their name, brand, and price.
# MAGIC
# MAGIC **Genie Code prompt:**
# MAGIC
# MAGIC <div style="position:relative; margin:6px 0;">
# MAGIC <button onclick="var t=document.getElementById('gp_438_3').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:5px 11px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#EEF3F5; border-left:3px solid #1B5162; border-radius:6px; padding:12px 14px; margin:0; font-size:14px; white-space:pre-wrap;"><code id="gp_438_3" style="white-space:pre-wrap; overflow-wrap:break-word;">From the products table, return the product&#95;name, brand, and list&#95;price of the five products with the highest list&#95;price, sorted from most to least expensive.</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Use Genie Code with the prompt above, then run the result.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Here is the full top-5 query</strong></summary>
# MAGIC <div style="position:relative; margin-top:8px;">
# MAGIC <button onclick="var t=document.getElementById('cb3').innerText;var ok=function(b){b.textContent='Copied';setTimeout(function(){b.textContent='Copy';},1500);};var b=this;try{navigator.clipboard.writeText(t).then(function(){ok(b);},function(){fb();});}catch(e){fb();}function fb(){var ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.focus();ta.select();try{document.execCommand('copy');ok(b);}catch(err){}document.body.removeChild(ta);}" style="position:absolute; top:8px; right:8px; background:#1B5162; color:#fff; border:none; border-radius:5px; padding:6px 12px; font-size:13px; cursor:pointer; z-index:1;">Copy</button>
# MAGIC <pre style="background:#F9F7F4; border-radius:6px; padding:14px; margin:0; font-size:14px; overflow:auto;"><code id="cb3">SELECT
# MAGIC   product_name,
# MAGIC   brand,
# MAGIC   list_price
# MAGIC FROM products
# MAGIC ORDER BY list_price DESC
# MAGIC LIMIT 5;</code></pre>
# MAGIC </div>
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC You should see five rows. The most expensive products are in the **Amplifiers** category, with list prices in the high four figures (close to $6,000). High-end vintage tube amplifiers and integrated amps are the priciest items in the catalog.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 4: Count stores by region - spot the correct query
# MAGIC
# MAGIC Vintage Audio Co. operates 30 stores grouped into four US regions: `Northeast`, `Southeast`, `Midwest`, and `West`. You want **one row per region with the number of stores in it**.
# MAGIC
# MAGIC Below are **two** queries. Both run without error, but only one answers the question. **Run them both**, look at the results, and decide which one is correct and why.
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query A
# MAGIC SELECT
# MAGIC   region,
# MAGIC   COUNT(*) AS store_count
# MAGIC FROM stores
# MAGIC GROUP BY region
# MAGIC ORDER BY store_count DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Query B
# MAGIC SELECT
# MAGIC   region,
# MAGIC   state,
# MAGIC   COUNT(*) AS store_count
# MAGIC FROM stores
# MAGIC GROUP BY region, state
# MAGIC ORDER BY store_count DESC;

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary><strong>Which one is correct?</strong></summary>
# MAGIC <div style="margin-top:8px; font-size:14px;">
# MAGIC <p><strong>Query A is correct.</strong> Grouping by <code>region</code> alone gives exactly one row per region, which is what the question asks for.</p>
# MAGIC <p><strong>Query B</strong> groups by <code>region</code> <em>and</em> <code>state</code>, so it returns one row per region-and-state combination &mdash; many more than four rows, splitting each region's count across its states. It answers a different question (&ldquo;stores per state within each region&rdquo;).</p>
# MAGIC <p>The lesson: the columns you <code>GROUP BY</code> decide the grain of the result. Add only the columns you actually want one row per.</p>
# MAGIC </div>
# MAGIC </details>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Query A returns four rows. The **West** region has the most stores (10), followed by **Midwest** and **Southeast** (7 each), then **Northeast** (6) - a national footprint that's reasonably well-distributed.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 5: Visualize the store footprint as a bar chart
# MAGIC
# MAGIC Turn the regional store counts into a **bar chart** so the distribution is easy to read at a glance.
# MAGIC
# MAGIC Run the cell below (it's the correct Query A from Task 4), then follow the steps to turn it into a bar chart.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   region,
# MAGIC   COUNT(*) AS store_count
# MAGIC FROM stores
# MAGIC GROUP BY region
# MAGIC ORDER BY store_count DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC **Build the bar chart:**
# MAGIC
# MAGIC 1. Above the result table, click the **`+`** icon and choose **Visualization**.
# MAGIC 2. Set the **Visualization Type** to **`Pie`**.
# MAGIC 3. Set the **X axis** to **`region`**.
# MAGIC 4. Set the **Y axis** to **`store_count`**, with **Aggregation** set to **`Sum`**.
# MAGIC 5. Click **Save**.
# MAGIC
# MAGIC You should see four slices, one per region, with **West** being the biggest. If the chart looks wrong, check that `region` is on the X axis and `store_count` is on the Y axis.
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Nice work
# MAGIC
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC
# MAGIC In this lab you:
# MAGIC
# MAGIC - Used <strong>Genie Code</strong> to build preview, count, and top-N queries from plain-language prompts.
# MAGIC - Compared two <code>GROUP BY</code> queries and identified which one answered the question, and why grain matters.
# MAGIC - Turned a result into a <strong>pie chart</strong> to visualize the regional store distribution.
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>