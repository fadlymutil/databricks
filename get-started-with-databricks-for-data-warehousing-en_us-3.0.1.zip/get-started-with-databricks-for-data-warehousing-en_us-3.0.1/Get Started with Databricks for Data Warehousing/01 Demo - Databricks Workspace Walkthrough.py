# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC
# MAGIC <div style="background: #1B5162; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lesson 01</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Databricks Workspace Walkthrough</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Navigate the workspace.</div>
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC In this short walkthrough, you will get oriented in your Databricks workspace and run your first cells. By the end, you will be ready to dive into the lessons that follow.
# MAGIC
# MAGIC **What you will do:**
# MAGIC 1. Confirm your compute is ready and run the classroom setup
# MAGIC 1. Run your first cell
# MAGIC 1. Tour the workspace sidebar
# MAGIC 1. Find data in the catalog
# MAGIC 1. Try notebook basics: cells, languages, and Genie Code
# MAGIC 1. Get oriented with SQL Warehouses
# MAGIC
# MAGIC > **Estimated time:** ~20 minutes
# MAGIC >
# MAGIC > **Note:** This is a follow-along walkthrough. Read the steps and try them in your own workspace as we go.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Setup
# MAGIC #### Confirm your compute is ready
# MAGIC
# MAGIC Look at the **top-right corner of this notebook** to confirm your compute is selected.
# MAGIC
# MAGIC - You should see **Serverless** selected by default.
# MAGIC - If a different cluster is selected, click the dropdown and choose **Serverless**.
# MAGIC
# MAGIC With Databricks serverless compute, you do not need to start or wait for a cluster. It attaches automatically when you run a cell.
# MAGIC
# MAGIC #### Run the classroom setup
# MAGIC
# MAGIC The cell below runs the classroom setup script. This points your session at the personal catalog and `vintage_audio` schema that the course uses. Click the **Run** button at the top-left of the cell (or press **Shift + Enter** while the cell is selected).

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01

# COMMAND ----------

# MAGIC %md
# MAGIC #### Confirm your environment
# MAGIC
# MAGIC Run the cell below to print your username, catalog, and schema. You will use these throughout the course.

# COMMAND ----------

# DBTITLE 1,select
# MAGIC %sql
# MAGIC SELECT current_user(), current_catalog(), current_schema();

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Run your first cell
# MAGIC
# MAGIC Now run a SQL cell to confirm everything is working. The cell below greets you and shows the current date and time.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   'Hello Databricks Learner!' AS greeting,
# MAGIC   current_date() AS today,
# MAGIC   current_timestamp() AS right_now, 'test' as new_column;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see a one-row result with your greeting, today's date, and the current time. **You just ran your first SQL query in Databricks.**

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Tour the workspace sidebar
# MAGIC
# MAGIC The left sidebar is your home base in Databricks. Hover over the **hamburger icon** (☰) at the top-left to expand it.
# MAGIC
# MAGIC The items you will use most often in this course:
# MAGIC
# MAGIC | Sidebar item | What it's for |
# MAGIC |---|---|
# MAGIC | **+ New** | Create a notebook, query, dashboard, job, or pipeline |
# MAGIC | **Workspace** | Browse and organize your own notebooks and folders |
# MAGIC | **Catalog** | Browse governed data: catalogs, schemas, tables, and volumes |
# MAGIC | **SQL Editor** | Author and save SQL queries that run on a SQL Warehouse |
# MAGIC | **Dashboards** | Build AI/BI dashboards from your data |
# MAGIC | **Query History** | See every query that has run, with timings and a profile |
# MAGIC | **SQL Warehouses** | View and configure SQL-optimized compute |
# MAGIC | **Search** (top bar) | Find any notebook, table, or asset by name |
# MAGIC
# MAGIC > 💡 **Try it:** Click the **Databricks logo** in the top-left to go to the workspace homepage. You will see Suggested, Favorites, and What's New tabs. Then click your browser's back button (or use Recents in the sidebar) to return to this notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Find data in the catalog
# MAGIC
# MAGIC All governed data in Databricks lives in **Unity Catalog**, organized in a three-level hierarchy: **catalog → schema → table**. Let's find a sample table that's available in every Databricks workspace.
# MAGIC
# MAGIC #### Browse to the table
# MAGIC
# MAGIC 1. In the left sidebar, click **Catalog** to open Catalog Explorer.
# MAGIC 1. Find and expand the **`samples`** catalog.
# MAGIC 1. Expand the **`nyctaxi`** schema.
# MAGIC 1. Click the **`trips`** table.
# MAGIC 1. On the right panel, look at the **Overview** tab to see the column list, then click the **Sample Data** tab to preview a few rows.
# MAGIC
# MAGIC You are looking at NYC taxi trip data: pickup and dropoff times, fare amounts, distances, and zip codes.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Query that same table from this notebook
# MAGIC
# MAGIC Run the cell below to query the table you just previewed.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM samples.nyctaxi.trips
# MAGIC LIMIT 10;

# COMMAND ----------

# MAGIC %md
# MAGIC You are now seeing the same data you previewed in Catalog Explorer, just queried directly in the notebook. This is the loop you will use throughout the course: **find data in the catalog, then work with it in a notebook.**

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Notebook basics: cells, languages, and Genie Code
# MAGIC Databricks notebooks support multiple languages in the same notebook. The cell below is Python. It counts the rows in the sample table and prints the result.

# COMMAND ----------

trip_count = spark.sql("SELECT COUNT(*) AS total FROM samples.nyctaxi.trips").collect()[0]["total"]
print(f"There are {trip_count:,} trips in the sample dataset.")

# COMMAND ----------

# MAGIC %md
# MAGIC #### Changing cell type
# MAGIC
# MAGIC Try adding a new cell to this notebook:
# MAGIC
# MAGIC 1. Hover between this cell and the next one. A **+ Code** button appears. Click it to add a new cell below.
# MAGIC 1. In the new cell, set the language to **SQL** using the dropdown at the top-right of the cell (or type `%sql` on the first line).
# MAGIC 1. Type: `SELECT MAX(fare_amount) AS biggest_fare FROM samples.nyctaxi.trips`
# MAGIC 1. Press **Shift + Enter** to run it.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT MAX(fare_amount) AS biggest_fare FROM samples.nyctaxi.trips

# COMMAND ----------

# MAGIC %md
# MAGIC #### Try Genie Code
# MAGIC
# MAGIC Genie Code can write, explain, and debug code for you. There are two ways to open it:
# MAGIC
# MAGIC - Click the **Genie icon** in the right sidebar to open the chat panel.
# MAGIC - Press **Cmd + I** (Mac) or **Ctrl + I** (Windows) inside a cell to invoke the in-cell Genie Code prompt.
# MAGIC
# MAGIC Try asking it: *"Write a SQL query that counts trips by pickup zip code from samples.nyctaxi.trips, sorted by trip count descending."*

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   pickup_zip,
# MAGIC   COUNT(*) AS trip_count
# MAGIC FROM samples.nyctaxi.trips
# MAGIC GROUP BY pickup_zip
# MAGIC ORDER BY trip_count DESC;

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### 6. SQL Warehouses
# MAGIC
# MAGIC The lessons that follow in this course primarily query data, and queries in Databricks run on a **SQL Warehouse**, which is a compute resource specifically optimized for SQL workloads against Unity Catalog managed tables.
# MAGIC
# MAGIC There are three types of SQL Warehouses. The three-card layout below summarizes the differences. **You will not create a SQL Warehouse in this course**: your workspace already has one provisioned that the course uses.
# MAGIC
# MAGIC <div style="max-width: 1100px; margin: 0 auto; font-family: sans-serif;">
# MAGIC
# MAGIC <div style="font-size: 20pt; font-weight: 700; color: #0b2026; margin-bottom: 6px;">Three Types of SQL Warehouses</div>
# MAGIC <div style="font-size: 13pt; color: #5A6F77; margin-bottom: 24px;">Different SQL Warehouse types offer different performance characteristics. For most use cases, Serverless is the recommended starting point.</div>
# MAGIC
# MAGIC <div style="display: flex; justify-content: center; align-items: stretch; gap: 24px; flex-wrap: wrap;">
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 240px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; gap: 10px; padding: 24px; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #FE3722; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Serverless</div>
# MAGIC     <div style="font-size: 11pt; color: #5E7077; text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Recommended</div>
# MAGIC     <div style="font-size: 13pt; color: #2c3e50;">Fastest startup, lowest operational overhead. Photon engine, Predictive IO, and Intelligent Workload Management are all enabled.</div>
# MAGIC   </div>
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 240px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; gap: 10px; padding: 24px; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #1B5162; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Pro</div>
# MAGIC     <div style="font-size: 11pt; color: #5E7077; text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Networking constraints</div>
# MAGIC     <div style="font-size: 13pt; color: #2c3e50;">Runs in your own cloud account. Suitable when network or compliance requirements prevent Serverless. Photon and Predictive IO are enabled.</div>
# MAGIC   </div>
# MAGIC
# MAGIC   <div style="width: 300px; min-height: 240px; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); display: flex; flex-direction: column; gap: 10px; padding: 24px; position: relative; box-sizing: border-box;">
# MAGIC     <div style="position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #618794; border-radius: 8px 8px 0 0;"></div>
# MAGIC     <div style="font-size: 16pt; font-weight: 600; color: #0b2026;">Classic</div>
# MAGIC     <div style="font-size: 11pt; color: #5E7077; text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Legacy</div>
# MAGIC     <div style="font-size: 13pt; color: #2c3e50;">Entry-level option. Photon is supported, but workloads do not benefit from the newer optimizations in Pro and Serverless.</div>
# MAGIC   </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC <div style="margin-top: 24px; padding: 14px 18px; background: #FFF7EC; border-left: 4px solid #FF9800; border-radius: 4px; color: #333; font-size: 13pt;">
# MAGIC <strong>Key point:</strong> In this course, the compute selector at the top-right of each notebook is set to <strong>Serverless</strong>. SQL queries you run will execute against a SQL Warehouse already provisioned in your workspace. You can confirm by clicking the <strong>SQL Warehouses</strong> entry in the sidebar.
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### What's next
# MAGIC
# MAGIC You are now oriented in Databricks. You have:
# MAGIC
# MAGIC - Confirmed your compute is ready and run the classroom setup
# MAGIC - Run SQL and Python cells in a notebook
# MAGIC - Browsed the catalog and queried a sample table
# MAGIC - Practiced adding cells, switching languages, and using Genie Code
# MAGIC - Reviewed the three types of SQL Warehouses

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>