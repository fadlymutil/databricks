# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md
# MAGIC # Get Started with Databricks for Data Warehousing
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This course introduces the foundational skills a warehousing practitioner needs to do day-to-day data warehousing work on the **Databricks Data Intelligence Platform**. You will explore the workspace, query Unity Catalog managed tables, optimize them for analytical reads, load data incrementally, model a star schema, deliver insights through dashboards and external BI tools, and diagnose slow queries, all from a single, governed environment.
# MAGIC
# MAGIC The course follows a hands-on path. After getting oriented in the workspace, you will work through guided **Demo** notebooks for each topic that walk you through key concepts with worked examples.
# MAGIC
# MAGIC The content covers:
# MAGIC
# MAGIC - The **Databricks Data Intelligence Platform** and how the workspace, **Unity Catalog**, and **SQL Warehouses** fit together.
# MAGIC - Writing SQL queries against governed Unity Catalog tables and visualizing the results inline.
# MAGIC - Keeping **UC managed tables** fast for analytical reads with **Predictive Optimization** and **automatic liquid clustering** (`CLUSTER BY AUTO`), and where manual commands still fit.
# MAGIC - Loading data into the warehouse incrementally using **Auto Loader**, with safe, exactly-once re-runs.
# MAGIC - Modeling a **star schema** in Unity Catalog with fact and dimension tables, surrogate keys, and informational primary and foreign key constraints.
# MAGIC - Defining a **Unity Catalog metric view** so every consumer (SQL Editor, dashboards, Genie Agents, alerts, and external BI tools) reads one trusted set of measure definitions.
# MAGIC
# MAGIC By the end of the course, you will be comfortable querying governed Unity Catalog tables, keeping UC managed tables optimized for analytical workloads, loading data incrementally with Auto Loader, modeling a star schema, and delivering consistent metrics through metric views.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Terminal Objectives
# MAGIC
# MAGIC By the end of this course, you will be able to:
# MAGIC
# MAGIC - **Navigate** the Databricks workspace, Unity Catalog, and SQL Warehouses to locate tables, run queries, and inspect results.
# MAGIC - **Write** SQL queries that join, aggregate, and filter Unity Catalog tables, and turn the results into inline visualizations.
# MAGIC - **Keep** UC managed tables fast for analytical reads with Predictive Optimization and automatic liquid clustering (`CLUSTER BY AUTO`), and recognize when manual commands such as `OPTIMIZE` or `ANALYZE` still apply.
# MAGIC - **Load** data into UC managed tables incrementally with Auto Loader, including verifying that re-runs do not duplicate rows.
# MAGIC - **Build** a star schema in Unity Catalog with fact and dimension tables, surrogate keys, a procedurally-generated date dimension, and informational primary and foreign key constraints.
# MAGIC - **Define** a Unity Catalog metric view and explain how the same definition feeds the SQL Editor, dashboards, Genie Agents, alerts, and external BI tools.
# MAGIC
# MAGIC ##### Course version and update information can be found in the `Version Info` file.

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Prerequisites
# MAGIC
# MAGIC Before starting this course, learners should be comfortable with the following:
# MAGIC
# MAGIC - **Basic familiarity with the data warehousing domain.** You understand at a conceptual level what a data warehouse is, what a table is, and what business intelligence (BI) tools are used for.
# MAGIC - **Working knowledge of SQL.** You can read and write `SELECT` statements with `WHERE`, `GROUP BY`, aggregate functions, and `JOIN`.
# MAGIC - **No prior Databricks knowledge is assumed.** Databricks-specific concepts (Unity Catalog, Delta Lake, SQL Warehouses, metric views) are introduced as they come up.

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Workspace Setup Information

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Compute and Permissions</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">This content assumes you have:</p>
# MAGIC
# MAGIC - **CAN USE access on Serverless compute resource**
# MAGIC - **Unity Catalog enabled** in your workspace.
# MAGIC - **Permission to create tables** in your personal catalog or schema.
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Databricks Provided Vocareum Workspace (Recommended)
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC
# MAGIC - If you are running this notebook in a **Databricks Academy provided Vocareum workspace**, your Unity Catalog catalog is already created for you.
# MAGIC - Your catalog name matches your Vocareum username and looks like: **labuser12345** (a unique series of numbers).
# MAGIC - The course schema (**`vintage_audio`**) is created inside your catalog by the setup script.
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B2. Databricks Free Edition or Other Workspaces (*as is*)
# MAGIC
# MAGIC ##### Databricks Free Edition or other workspaces may work for this course, but support is provided **as is**.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC
# MAGIC #### Catalog Information
# MAGIC
# MAGIC - If you are running this notebook in your own Databricks workspace or Databricks Free Edition, the setup will **create a Unity Catalog catalog and schema for you**.
# MAGIC - The **Create Catalog** permission is required.
# MAGIC - The catalog name is derived from your Databricks username and follows this pattern: **`labuser_<your_username>`**.
# MAGIC - The course schema (**`vintage_audio`**) and a **`data`** volume are created inside that catalog by the setup script.
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="display:block; color:#e65100; margin-bottom:6px; font-size: 1.1em;">Troubleshooting Setup: Your Workspace Cannot Create Catalogs</strong>
# MAGIC <details>
# MAGIC <div style="color:#333;">
# MAGIC
# MAGIC If you do not have permission to create a new catalog but already have one available, you can explicitly point the setup at an existing catalog by editing `Classroom-Setup-Common` and forcing the catalog name in the `safe_uc_name` / catalog-resolution block.
# MAGIC
# MAGIC </div>
# MAGIC </details>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Do Not Run in Production Environments</strong>
# MAGIC
# MAGIC - Only run this course in **development or sandbox workspaces**.
# MAGIC - Do not run in production environments. The setup scripts create catalogs, schemas, volumes, and tables in your workspace.
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Course Structure
# MAGIC
# MAGIC The course is organized as paired Demo and Lab notebooks. Demos walk you through each concept; Labs ask you to apply it on your own.
# MAGIC
# MAGIC | # | Notebook | Type |
# MAGIC |---|---|---|
# MAGIC | 00 | [00 - Course Overview]($./00 - Course Overview) | Reference |
# MAGIC | 01| [01 Demo - Databricks Workspace Walkthrough]($./01 Demo - Databricks Workspace Walkthrough) | Demo |
# MAGIC | 02| [02 Demo - Querying the Vintage Audio Warehouse]($./02 Demo - Querying the Vintage Audio Warehouse) | Demo |
# MAGIC | 03| [03 Lab - Explore the Vintage Audio Tables]($./03 Lab - Explore the Vintage Audio Tables) | Lab |
# MAGIC | 04| [04 Demo - Tuning Unity Catalog managed Tables for Analytical Queries]($./04 Demo - Tuning Unity Catalog managed Tables for Analytical Queries) | Demo |
# MAGIC | 05| [05 Lab - Optimize the Products Table]($./05 Lab - Optimize the Products Table) | Lab |
# MAGIC | 06| [06 Demo - Loading Data into the Warehouse]($./06 Demo - Loading Data into the Warehouse) | Demo |
# MAGIC | 07| [07 Lab - Incrementally Load New Orders]($./07 Lab - Incrementally Load New Orders) | Lab |
# MAGIC | 08| [08 Demo - Building a Star Schema]($./08 Demo - Building a Star Schema) | Demo |
# MAGIC | 09| [09 Lab - Build a Store Dimension]($./09 Lab - Build a Store Dimension) | Lab |
# MAGIC | 10| [10 Demo - Deliver Insights with Metric Views]($./10 Demo - Deliver Insights with Metric Views) | Demo |
# MAGIC | 11| [11 Lab - Create a Metric View for Store Performance]($./11 Lab - Create a Metric View for Store Performance) | Lab |
# MAGIC | -| [Capstone Lab - Vintage Audio Quarterly Performance Review]($./Capstone Lab - Vintage Audio Quarterly Performance Review) | Lab |
# MAGIC | -|[Summary and Next Steps]($./Summary and Next Steps) | Reference |

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. The Vintage Audio Co. Dataset
# MAGIC
# MAGIC Every demo and lab in this course uses a single dataset that we built specifically for warehousing scenarios: **Vintage Audio Co.**, a fictional retailer that sells vintage hi-fi audio equipment through 30 stores across the United States.
# MAGIC
# MAGIC The dataset is shipped as CSV files and prepared in your workspace automatically by each lesson's setup. The assets the course uses:
# MAGIC
# MAGIC | Asset | Created where | Used by |
# MAGIC |---|---|---|
# MAGIC | `customers` table | `vintage_audio` schema | Lessons 02, 04 |
# MAGIC | `products` table | `vintage_audio` schema | Lessons 02, 03, 04, 05 |
# MAGIC | `stores` table | `vintage_audio` schema | Lessons 02, 03 |
# MAGIC | Six quarterly `orders_*.csv` files | `data` volume | Lessons 06, 07 (Auto Loader ingestion) |
# MAGIC
# MAGIC The order CSV files are intentionally left in the volume rather than pre-loaded as tables, because loading them with Auto Loader is the subject of Lesson 06.

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. You're ready to start
# MAGIC
# MAGIC There's nothing to run here. Each Demo and Lab begins with its own short setup cell that silently prepares everything that notebook needs (catalog, schema, volume, staged files, and any tables), so you can start anywhere.
# MAGIC
# MAGIC Continue with **Lesson 01: Databricks Workspace Walkthrough** next.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>