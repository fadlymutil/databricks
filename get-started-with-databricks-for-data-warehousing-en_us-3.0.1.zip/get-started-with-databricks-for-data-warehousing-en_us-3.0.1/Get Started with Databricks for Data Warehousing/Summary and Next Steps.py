# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md
# MAGIC # Summary and Next Steps

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## What You Built in This Course
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 10px; padding: 20px 24px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); border-top: 6px solid #1B5162; margin: 16px 0;">
# MAGIC <div style="font-size: 14pt; color: #0b2026; line-height: 1.7;">
# MAGIC
# MAGIC Over the course of these lessons, you went from raw CSV files to a governed, query-ready data warehouse for the fictional Vintage Audio Co. retailer. Specifically, you:
# MAGIC
# MAGIC - **Got oriented** in the Databricks Workspace and located data through Catalog Explorer and the three-level namespace, backed by Serverless SQL Warehouses.
# MAGIC - **Wrote SQL queries** from a notebook against governed Unity Catalog tables, including joins, aggregates, and filtering, and turned a result into an inline visualization.
# MAGIC - **Used Genie Code** to generate SQL from natural-language prompts and to explain unfamiliar queries.
# MAGIC - **Tuned Unity Catalog managed tables** for analytical reads with Predictive Optimization and automatic liquid clustering (`CLUSTER BY AUTO`), and used `DESCRIBE HISTORY`, time travel with `VERSION AS OF`, and `RESTORE TABLE` to audit and recover changes.
# MAGIC - **Loaded data incrementally** with Auto Loader, confirming that re-runs are exactly-once and never duplicate rows.
# MAGIC - **Built a star schema** with fact and dimension tables, surrogate keys, a procedurally-generated date dimension, and informational primary and foreign key constraints.
# MAGIC - **Defined Unity Catalog metric views** so every consumer (the SQL Editor, dashboards, Genie Agents, alerts, and external BI tools) reads one trusted set of measure definitions.
# MAGIC
# MAGIC These are the same building blocks warehousing practitioners use in production Databricks workspaces every day.
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Keep Using Genie Code Beyond This Course
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 10px; padding: 20px 24px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); border-top: 6px solid #FF5F46; margin: 16px 0;">
# MAGIC <div style="font-size: 14pt; color: #0b2026; line-height: 1.7;">
# MAGIC
# MAGIC <strong>Genie Code</strong> lives in every notebook and the SQL editor. Use it to draft SQL from natural language, explain an unfamiliar query, refactor a statement, or generate a starting point you can refine.
# MAGIC
# MAGIC Two ways to invoke it inside a notebook or SQL cell:
# MAGIC
# MAGIC <ul>
# MAGIC   <li>Click the <strong>Genie Code icon</strong> at the top-right of any cell.</li>
# MAGIC   <li>Press <strong>Cmd + I</strong> (macOS) or <strong>Ctrl + I</strong> (Windows / Linux) inside any cell to open the in-cell prompt.</li>
# MAGIC </ul>
# MAGIC
# MAGIC To have Genie Code <em>explain</em> an existing query rather than write a new one, select the cell and open Genie Code from the panel on the right. The faster you build the habit of describing what you want, the faster the platform can help you.
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Additional Resources
# MAGIC
# MAGIC Explore these resources to keep learning and stay current with the Databricks Data Intelligence Platform. The links below come from the official Databricks documentation and product pages.
# MAGIC
# MAGIC #### Core Concepts
# MAGIC
# MAGIC - **Unity Catalog**: discovery, governance, and the three-level namespace:
# MAGIC [AWS](https://docs.databricks.com/aws/en/data-governance/unity-catalog/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/data-governance/unity-catalog/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/data-governance/unity-catalog/)
# MAGIC
# MAGIC - **Delta Lake**: versioning, time travel, schema management:
# MAGIC [AWS](https://docs.databricks.com/aws/en/delta/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/delta/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/delta/)
# MAGIC
# MAGIC - **SQL Warehouses** (Serverless and Pro), compute purpose-built for SQL:
# MAGIC [AWS](https://docs.databricks.com/aws/en/compute/sql-warehouse/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/compute/sql-warehouse/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/compute/sql-warehouse/)
# MAGIC
# MAGIC #### Optimizing and Loading Data
# MAGIC
# MAGIC - **Predictive Optimization**: automatic `OPTIMIZE`, `ANALYZE`, and `VACUUM` on managed tables:
# MAGIC [AWS](https://docs.databricks.com/aws/en/optimizations/predictive-optimization) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/optimizations/predictive-optimization) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/optimizations/predictive-optimization)
# MAGIC
# MAGIC - **Liquid clustering**: `CLUSTER BY` and automatic clustering for fast analytical reads:
# MAGIC [AWS](https://docs.databricks.com/aws/en/delta/clustering) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/delta/clustering) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/delta/clustering)
# MAGIC
# MAGIC - **Auto Loader**: incremental, exactly-once ingestion of files from cloud storage:
# MAGIC [AWS](https://docs.databricks.com/aws/en/ingestion/cloud-object-storage/auto-loader/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/ingestion/cloud-object-storage/auto-loader/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/ingestion/cloud-object-storage/auto-loader/)
# MAGIC
# MAGIC #### Modeling and Delivering Metrics
# MAGIC
# MAGIC - **Metric views**: define measures and dimensions once for every consumer:
# MAGIC [AWS](https://docs.databricks.com/aws/en/metric-views/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/metric-views/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/metric-views/)
# MAGIC
# MAGIC - **AI/BI Dashboards and Genie Agents**: deliver and explore governed metrics:
# MAGIC [AWS](https://docs.databricks.com/aws/en/dashboards/) |
# MAGIC [Azure](https://learn.microsoft.com/azure/databricks/dashboards/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/dashboards/)
# MAGIC
# MAGIC #### Productivity and AI Authoring
# MAGIC
# MAGIC - **Genie Code** in notebooks and the SQL editor:
# MAGIC [AWS](https://docs.databricks.com/aws/en/genie-code/) |
# MAGIC [Azure](https://learn.microsoft.com/en-us/azure/databricks/genie-code/) |
# MAGIC [GCP](https://docs.databricks.com/gcp/en/genie-code/)
# MAGIC
# MAGIC #### Vision and Roadmap
# MAGIC
# MAGIC - [Databricks Data Intelligence Platform](https://www.databricks.com/product/data-intelligence-platform), the broader vision behind everything in this course.
# MAGIC - [What is data warehousing on Databricks?](https://www.databricks.com/product/databricks-sql), context for how SQL warehousing fits the platform.

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Next Steps
# MAGIC
# MAGIC Continue building your data warehousing and analytics skills with additional training and a certification path.
# MAGIC
# MAGIC Recommended next courses to deepen the skills you started here. Each is available self-paced and as instructor-led training:
# MAGIC
# MAGIC - **Building ETL Pipelines with SQL**
# MAGIC - **Data Interoperability with Unity Catalog**
# MAGIC - **Building Semantic Models in Databricks with UC Metric Views**
# MAGIC - **Designing Data Models and Architectures**
# MAGIC - **SQL Programming and Procedural Logic**
# MAGIC - **Architecting DBSQL for Large-Scale Deployments**
# MAGIC
# MAGIC Browse the full catalog at **[Databricks Training and Certification](https://www.databricks.com/learn/training/home)**.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>