# Databricks notebook source
# MAGIC %md
# MAGIC ![DB Academy](https://files.training.databricks.com/binder/prod_main/get-started-with-databricks-for-data-warehousing-en_us-3.0.1/images/20260812T181442Z/Get Started with Databricks for Data Warehousing/Includes/images/db-academy.png)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <div style="max-width: 1000px; margin: 0 auto; font-family: sans-serif;">
# MAGIC <div style="background: #1B5162; color: white; border-radius: 8px; padding: 28px 32px; text-align: center; position: relative;">
# MAGIC   <div style="font-size: 14pt; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; opacity: 0.85; margin-bottom: 8px;">Lesson 10</div>
# MAGIC   <div style="font-size: 24pt; font-weight: 700; line-height: 1.3;">Deliver Insights with Metric Views</div>
# MAGIC   <div style="font-size: 14pt; margin-top: 12px; opacity: 0.9;">Read a metric view's YAML definition in the Catalog Explorer UI, then learn how to query it.</div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## REQUIRED: SELECT A COMPUTE ENVIRONMENT
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <strong style="display:block; color:#c62828; margin-bottom:6px; font-size: 1.1em;">Select Serverless Compute</strong>
# MAGIC   <div style="color:#333;">
# MAGIC
# MAGIC This notebook runs on Serverless compute. Before running any cells, confirm Serverless is selected in the compute dropdown at the top-right of this notebook. This course was developed and tested on <strong>Serverless environment version 5</strong>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### Setup
# MAGIC Run the cell below to configure your environment for this lesson. The setup script will initialize your catalog and schema, and **create the demo metric view** you will explore in this lesson. The metric view is created for you automatically so this lesson can focus on reading and querying it rather than authoring YAML.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-10

# COMMAND ----------

# MAGIC %md
# MAGIC ## What this lesson covers
# MAGIC
# MAGIC You have built a clean star schema. Anyone with SQL skills can now answer business questions by writing the right `SELECT`. But not everyone in the business writes SQL, and even SQL writers benefit from a shared definition of what counts as "revenue" or "order count" so two teams do not end up with two different numbers for the same metric.
# MAGIC
# MAGIC A **metric view** is Unity Catalog's answer to this problem. You define your dimensions and measures once, in one place, using a YAML specification authored in the Catalog Explorer UI. Every consumer (SQL Editor, AI/BI dashboards, Genie Agents, alerts, and external BI tools like Power BI and Tableau) then reads from the same definition.
# MAGIC
# MAGIC In this lesson you will:
# MAGIC
# MAGIC 1. See why metric views matter for keeping metric definitions consistent.
# MAGIC 2. Open a metric view that was pre-created for you in Catalog Explorer.
# MAGIC 3. Explore it in the low-code UI (joins, measures, dimensions).
# MAGIC 4. Walk through the YAML definition section by section.
# MAGIC 5. Query the metric view, and use Genie Code to explain a query.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 1. Why metric views exist
# MAGIC
# MAGIC Without metric views, every consuming tool defines metrics on its own: the SQL analyst writes `SUM(total_amount)`, the dashboard author wires up a different aggregation, the Power BI report duplicates the logic, and a Genie Agent infers something plausible. Five tools, four definitions of "revenue," and a long argument in the next quarterly meeting.
# MAGIC
# MAGIC With a metric view, all consumers read the same definition.
# MAGIC
# MAGIC <div style="width: 100%; max-width: 880px; margin: 16px auto;">
# MAGIC <svg viewBox="0 0 920 520" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" style="width: 100%; height: auto; display: block;">
# MAGIC <text x="460" y="30" text-anchor="middle" fill="#1B5162" font-size="19" font-weight="700">ONE METRIC VIEW, MANY CONSUMERS</text>
# MAGIC <text x="460" y="54" text-anchor="middle" fill="#5E7077" font-size="15" font-style="italic">Define your business metrics once. Every tool reads the same definition.</text>
# MAGIC <!-- upstream tables feeding the metric view -->
# MAGIC <rect x="276" y="76" width="368" height="44" rx="6" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.2" stroke-dasharray="5,3"/>
# MAGIC <text x="460" y="103" text-anchor="middle" fill="#5E7077" font-size="15">fact_orders + dimensions (the star schema)</text>
# MAGIC <line x1="460" y1="120" x2="460" y2="150" stroke="#9AA7AD" stroke-width="1.5"/>
# MAGIC <text x="476" y="139" text-anchor="start" fill="#5E7077" font-size="15" font-style="italic">loaded by Spark Declarative Pipelines / Auto Loader</text>
# MAGIC <!-- the metric view -->
# MAGIC <rect x="310" y="150" width="300" height="96" rx="10" fill="#F9F7F4" stroke="#FE3722" stroke-width="2.5"/>
# MAGIC <text x="460" y="180" text-anchor="middle" fill="#0b2026" font-size="17" font-weight="700">vw_product_metrics</text>
# MAGIC <text x="460" y="202" text-anchor="middle" fill="#FE3722" font-size="15" font-weight="700" letter-spacing="1">METRIC VIEW</text>
# MAGIC <text x="460" y="226" text-anchor="middle" fill="#5E7077" font-size="15">measures: total_revenue, order_count</text>
# MAGIC <!-- five consumer boxes -->
# MAGIC <rect x="20" y="330" width="165" height="120" rx="8" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <text x="102" y="362" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">SQL Editor</text>
# MAGIC <text x="102" y="386" text-anchor="middle" fill="#5E7077" font-size="15">ad-hoc analyst</text>
# MAGIC <text x="102" y="404" text-anchor="middle" fill="#5E7077" font-size="15">queries</text>
# MAGIC <rect x="200" y="330" width="165" height="120" rx="8" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <text x="282" y="362" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">AI/BI</text>
# MAGIC <text x="282" y="382" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Dashboards</text>
# MAGIC <text x="282" y="406" text-anchor="middle" fill="#5E7077" font-size="15">stakeholder views</text>
# MAGIC <rect x="380" y="330" width="165" height="120" rx="8" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <text x="462" y="362" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Genie Agents</text>
# MAGIC <text x="462" y="386" text-anchor="middle" fill="#5E7077" font-size="15">natural-language</text>
# MAGIC <text x="462" y="404" text-anchor="middle" fill="#5E7077" font-size="15">questions</text>
# MAGIC <rect x="560" y="330" width="165" height="120" rx="8" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <text x="642" y="362" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">Alerts</text>
# MAGIC <text x="642" y="386" text-anchor="middle" fill="#5E7077" font-size="15">threshold-based</text>
# MAGIC <text x="642" y="404" text-anchor="middle" fill="#5E7077" font-size="15">notifications</text>
# MAGIC <rect x="740" y="330" width="165" height="120" rx="8" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <text x="822" y="362" text-anchor="middle" fill="#0b2026" font-size="15" font-weight="700">External BI</text>
# MAGIC <text x="822" y="386" text-anchor="middle" fill="#5E7077" font-size="15">Power BI, Tableau</text>
# MAGIC <text x="822" y="404" text-anchor="middle" fill="#5E7077" font-size="15">via Partner Connect</text>
# MAGIC <!-- connectors metric view -> consumers -->
# MAGIC <line x1="380" y1="246" x2="102" y2="330" stroke="#618794" stroke-width="1.5"/>
# MAGIC <line x1="420" y1="246" x2="282" y2="330" stroke="#618794" stroke-width="1.5"/>
# MAGIC <line x1="460" y1="246" x2="462" y2="330" stroke="#618794" stroke-width="1.5"/>
# MAGIC <line x1="500" y1="246" x2="642" y2="330" stroke="#618794" stroke-width="1.5"/>
# MAGIC <line x1="540" y1="246" x2="822" y2="330" stroke="#618794" stroke-width="1.5"/>
# MAGIC <text x="460" y="486" text-anchor="middle" fill="#5E7077" font-size="15" font-style="italic">Each consumer evaluates the same measure definitions &#8212; no duplicated metric logic.</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 2. Open the metric view in Catalog Explorer
# MAGIC
# MAGIC The setup at the top of this notebook created a metric view called **`vw_product_metrics`** in your `vintage_audio` schema. Open it now so you can read its YAML definition while you go through the rest of this lesson.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 12px 0; font-size: 15px; color: #333; line-height: 1.6;">
# MAGIC   <strong style="color: #1565c0; font-size: 16px;">Try this in Catalog Explorer</strong>
# MAGIC   <ol style="margin: 8px 0 0 0; padding-left: 20px;">
# MAGIC     <li>In the left sidebar, right-click on <strong>Catalog</strong> and choose <strong>Open Link in New Tab</strong>. Keep this notebook open in its own tab.</li>
# MAGIC     <li>Navigate to your catalog (starting with <code style="font-size: 15px;">labuser</code>) &#x2192; <strong>vintage_audio</strong> schema.</li>
# MAGIC     <li>Click on <strong>vw_product_metrics</strong>. The metric view page has tabs: <strong>Overview</strong> (dimensions and measures), <strong>Details</strong> (YAML), <strong>Lineage</strong> (related assets), <strong>Permissions</strong>, and <strong>Insights</strong>.</li>
# MAGIC     <li>In the top-right of the page, click <strong>Edit</strong> to open the metric view editor.</li>
# MAGIC     <li>The editor has two modes (toggled top-right): <strong>UI</strong> (low-code visual editor) and <strong>YAML</strong> (raw definition). Start with <strong>UI</strong>.</li>
# MAGIC   </ol>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 3. Explore the metric view in the low-code UI
# MAGIC
# MAGIC With the editor open in **UI** mode, you can inspect each part of the metric view visually before looking at the raw YAML. The UI is in active development, and it's a fast way to understand a metric view someone else authored.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 12px 0; font-size: 15px; color: #333; line-height: 1.6;">
# MAGIC   <strong style="color: #1565c0; font-size: 16px;">Walk through these in the UI</strong>
# MAGIC   <ul style="margin: 8px 0 0 0; padding-left: 20px;">
# MAGIC     <li><strong>The join:</strong> Find the join to <code style="font-size: 15px;">dim_product</code> and click it. The UI shows the joined table, the join condition, and a link into the <strong>lineage graph</strong>.</li>
# MAGIC     <li><strong>The dimensions:</strong> Click on a dimension such as <strong>Category</strong>. The UI shows the underlying expression and the display name.</li>
# MAGIC     <li><strong>The measures:</strong> Click on a measure such as <strong>Total Revenue</strong>. You will see the expression (<code style="font-size: 15px;">SUM(...)</code>), display name, and any <strong>comments</strong> or <strong>synonyms</strong>. Synonyms let someone ask Genie for "sales" or "turnover" and still hit <code style="font-size: 15px;">total_revenue</code>.</li>
# MAGIC   </ul>
# MAGIC   <p style="margin: 8px 0 0 0;">When done, switch the editor to <strong>YAML</strong> mode (top-right toggle) for the next section.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 4. Reading the YAML
# MAGIC
# MAGIC A metric view's YAML has several sections. The one you're looking at uses five: `version`, `source`, `joins`, `dimensions`, and `measures`. We'll walk through each.
# MAGIC
# MAGIC ### 4.1 `version` and `source`
# MAGIC
# MAGIC <div style="display: flex; gap: 16px; margin: 12px 0; font-family: -apple-system, sans-serif; align-items: stretch;">
# MAGIC   <div style="flex: 1; background: #f4f6f7; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 18px; font-family: Consolas, Monaco, monospace; font-size: 17px; color: #1B3139; line-height: 2.2;">
# MAGIC     <span style="color: #1B5162; font-weight: 700;">version:</span> <span style="color: #B26A00;">1.1</span><br/>
# MAGIC     <span style="color: #1B5162; font-weight: 700;">source:</span> &lt;catalog&gt;.vintage_audio.<span style="color: #00A972; font-weight: 700;">fact_orders</span>
# MAGIC   </div>
# MAGIC   <div style="flex: 1.2; display: flex; flex-direction: column; gap: 8px;">
# MAGIC     <div style="background: #f8fafc; border: 2px solid #DCE0E2; border-radius: 8px; padding: 14px 18px; flex: 1; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">version</span>
# MAGIC       <span style="color: #3d5a65;">Spec format. Keep as <code style="font-size: 16px; background: #EEEDE9; padding: 2px 6px; border-radius: 3px;">1.1</code></span>
# MAGIC     </div>
# MAGIC     <div style="background: #f8fafc; border: 2px solid #DCE0E2; border-radius: 8px; padding: 14px 18px; flex: 1; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">source</span>
# MAGIC       <span style="color: #3d5a65;">The fact table all measures compute from: <strong>fact_orders</strong></span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### 4.2 `joins`
# MAGIC
# MAGIC <div style="display: flex; gap: 16px; margin: 12px 0; font-family: -apple-system, sans-serif; align-items: stretch;">
# MAGIC   <div style="flex: 1; background: #f4f6f7; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 18px; font-family: Consolas, Monaco, monospace; font-size: 17px; color: #1B3139; line-height: 2;">
# MAGIC     <span style="color: #1B5162; font-weight: 700;">joins:</span><br/>
# MAGIC     &nbsp;&nbsp;- <span style="color: #1B5162; font-weight: 700;">name:</span> <span style="color: #00A972;">dim_product</span><br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">source:</span> &lt;catalog&gt;...dim_product<br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">"on":</span> <span style="color: #B26A00;">dim_product</span>.product_key = <span style="color: #B26A00;">source</span>.product_key
# MAGIC   </div>
# MAGIC   <div style="flex: 1.2; display: flex; flex-direction: column; gap: 8px;">
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">name</span>
# MAGIC       <span style="color: #3d5a65;">Label for this join: <strong>dim_product</strong></span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">source</span>
# MAGIC       <span style="color: #3d5a65;">The dimension table's full name</span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">"on"</span>
# MAGIC       <span style="color: #3d5a65;">Join condition: match <strong>product_key</strong> between tables</span>
# MAGIC     </div>
# MAGIC     <div style="font-size: 15px; color: #5E7077; padding: 4px 0;"><code style="font-size: 15px;">source</code> = fact_orders, <code style="font-size: 15px;">dim_product</code> = the join named above. <code style="font-size: 15px;">"on"</code> is quoted because <code style="font-size: 15px;">on</code> is a YAML reserved word.</div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### 4.3 `dimensions`
# MAGIC
# MAGIC **Dimensions are the columns consumers slice and filter by.** This metric view exposes two, both from `dim_product`:
# MAGIC
# MAGIC <div style="display: flex; gap: 16px; margin: 12px 0; font-family: -apple-system, sans-serif; align-items: stretch;">
# MAGIC   <div style="flex: 1; background: #f4f6f7; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 18px; font-family: Consolas, Monaco, monospace; font-size: 17px; color: #1B3139; line-height: 2;">
# MAGIC     <span style="color: #1B5162; font-weight: 700;">dimensions:</span><br/>
# MAGIC     &nbsp;&nbsp;- <span style="color: #1B5162; font-weight: 700;">name:</span> <span style="color: #00A972;">category</span><br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">expr:</span> dim_product.category<br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">display_name:</span> <span style="color: #B26A00;">Category</span><br/>
# MAGIC     &nbsp;&nbsp;- <span style="color: #1B5162; font-weight: 700;">name:</span> <span style="color: #00A972;">brand</span><br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">expr:</span> dim_product.brand<br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">display_name:</span> <span style="color: #B26A00;">Brand</span>
# MAGIC   </div>
# MAGIC   <div style="flex: 1.2; display: flex; flex-direction: column; gap: 8px;">
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">name</span>
# MAGIC       <span style="color: #3d5a65;">How SQL queries reference it: <code style="font-size: 15px;">GROUP BY category</code></span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">expr</span>
# MAGIC       <span style="color: #3d5a65;">The underlying column or SQL expression</span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">display_name</span>
# MAGIC       <span style="color: #3d5a65;">Friendly label for dashboards and Genie: <strong>Category</strong></span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### 4.4 `measures`
# MAGIC
# MAGIC **Measures are aggregations with built-in logic.** The query writer doesn't choose SUM vs AVG vs COUNT -- the metric view already knows.
# MAGIC
# MAGIC <div style="display: flex; gap: 16px; margin: 12px 0; font-family: -apple-system, sans-serif; align-items: stretch;">
# MAGIC   <div style="flex: 1; background: #f4f6f7; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 18px; font-family: Consolas, Monaco, monospace; font-size: 17px; color: #1B3139; line-height: 2;">
# MAGIC     <span style="color: #1B5162; font-weight: 700;">measures:</span><br/>
# MAGIC     &nbsp;&nbsp;- <span style="color: #1B5162; font-weight: 700;">name:</span> <span style="color: #00A972;">total_revenue</span><br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">expr:</span> <span style="color: #00A972;">SUM</span>(source.total_amount)<br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">display_name:</span> <span style="color: #B26A00;">Total Revenue</span><br/>
# MAGIC     &nbsp;&nbsp;- <span style="color: #1B5162; font-weight: 700;">name:</span> <span style="color: #00A972;">order_count</span><br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">expr:</span> <span style="color: #00A972;">COUNT</span>(source.order_id)<br/>
# MAGIC     &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #1B5162; font-weight: 700;">display_name:</span> <span style="color: #B26A00;">Order Count</span>
# MAGIC   </div>
# MAGIC   <div style="flex: 1.2; display: flex; flex-direction: column; gap: 8px;">
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">name</span>
# MAGIC       <span style="color: #3d5a65;">How SQL references it: <code style="font-size: 15px;">MEASURE(total_revenue)</code></span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">expr</span>
# MAGIC       <span style="color: #3d5a65;">The aggregation: <strong>SUM(...)</strong> or <strong>COUNT(...)</strong> built in</span>
# MAGIC     </div>
# MAGIC     <div style="background: #EDF5F7; border: 2px solid #1B5162; border-radius: 8px; padding: 14px 18px; font-size: 16px; display: flex; align-items: center; gap: 12px;">
# MAGIC       <span style="background: #1B5162; color: #fff; padding: 4px 12px; border-radius: 4px; font-weight: 700; font-size: 15px; flex-shrink: 0;">display_name</span>
# MAGIC       <span style="color: #3d5a65;">Friendly label: <strong>Total Revenue</strong>, <strong>Order Count</strong></span>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 5. Putting it all together
# MAGIC
# MAGIC Now that you have walked through each section, the diagram below summarizes what you have just read.
# MAGIC
# MAGIC <div style="width: 100%; max-width: 1120px; margin: 16px auto;">
# MAGIC <svg viewBox="0 0 920 470" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" style="width: 100%; height: auto; display: block;">
# MAGIC <text x="460" y="30" text-anchor="middle" fill="#1B5162" font-size="19" font-weight="700">ANATOMY OF A METRIC VIEW</text>
# MAGIC <text x="460" y="54" text-anchor="middle" fill="#5E7077" font-size="15" font-style="italic">The YAML you just read, broken down section by section.</text>
# MAGIC <rect x="20" y="78" width="360" height="372" rx="10" fill="#F9F7F4" stroke="#1B5162" stroke-width="1.5"/>
# MAGIC <rect x="40" y="98" width="320" height="56" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.4"/>
# MAGIC <text x="54" y="122" fill="#FE3722" font-size="15" font-weight="700">version</text>
# MAGIC <text x="54" y="142" fill="#5E7077" font-size="15" font-style="italic">spec version</text>
# MAGIC <rect x="40" y="162" width="320" height="56" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.4"/>
# MAGIC <text x="54" y="186" fill="#FE3722" font-size="15" font-weight="700">source</text>
# MAGIC <text x="54" y="206" fill="#5E7077" font-size="15" font-style="italic">the fact table</text>
# MAGIC <rect x="40" y="226" width="320" height="56" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.4"/>
# MAGIC <text x="54" y="250" fill="#FE3722" font-size="15" font-weight="700">joins</text>
# MAGIC <text x="54" y="270" fill="#5E7077" font-size="15" font-style="italic">bring in dimension tables</text>
# MAGIC <rect x="40" y="290" width="320" height="66" rx="5" fill="#FFFFFF" stroke="#1B5162" stroke-width="1.4"/>
# MAGIC <text x="54" y="314" fill="#FE3722" font-size="15" font-weight="700">dimensions</text>
# MAGIC <text x="54" y="334" fill="#5E7077" font-size="15" font-style="italic">slice &amp; filter by &#8212; category, brand</text>
# MAGIC <rect x="40" y="364" width="320" height="70" rx="5" fill="#FFFFFF" stroke="#FE3722" stroke-width="2"/>
# MAGIC <text x="54" y="388" fill="#FE3722" font-size="15" font-weight="700">measures</text>
# MAGIC <text x="54" y="408" fill="#5E7077" font-size="15" font-style="italic">aggregations &#8212; total_revenue,</text>
# MAGIC <text x="54" y="426" fill="#5E7077" font-size="15" font-style="italic">order_count</text>
# MAGIC <rect x="400" y="78" width="500" height="372" rx="8" fill="#FFF7EC" stroke="#FF9800" stroke-width="2"/>
# MAGIC <text x="420" y="106" fill="#B26A00" font-size="15" font-weight="700" letter-spacing="1">HOW TO QUERY IT</text>
# MAGIC <text x="420" y="132" fill="#0b2026" font-size="15" font-weight="700">Dimensions: referenced by name as columns.</text>
# MAGIC <text x="420" y="154" fill="#0b2026" font-size="15" font-weight="700">Measures: wrapped in MEASURE().</text>
# MAGIC <rect x="420" y="172" width="460" height="200" rx="6" fill="#FFFFFF" stroke="#FF9800" stroke-width="1"/>
# MAGIC <text x="436" y="200" fill="#0b2026" font-size="15" font-family="monospace">SELECT</text>
# MAGIC <text x="436" y="222" fill="#0b2026" font-size="15" font-family="monospace">  category,</text>
# MAGIC <text x="436" y="244" fill="#FE3722" font-size="15" font-family="monospace">  MEASURE(total_revenue),</text>
# MAGIC <text x="436" y="266" fill="#FE3722" font-size="15" font-family="monospace">  MEASURE(order_count)</text>
# MAGIC <text x="436" y="288" fill="#0b2026" font-size="15" font-family="monospace">FROM vw_product_metrics</text>
# MAGIC <text x="436" y="310" fill="#0b2026" font-size="15" font-family="monospace">GROUP BY ALL;</text>
# MAGIC <text x="420" y="402" fill="#5E7077" font-size="15" font-style="italic">The same query works from the SQL Editor,</text>
# MAGIC <text x="420" y="422" fill="#5E7077" font-size="15" font-style="italic">dashboards, Genie Agents, and external BI tools.</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 6. Query the metric view
# MAGIC
# MAGIC Now that you have explored the metric view in Catalog Explorer and read its YAML, let's query it from this notebook.
# MAGIC
# MAGIC Metric views look like regular views, but querying them has two rules and one helpful shorthand:
# MAGIC
# MAGIC <div style="width: 100%; margin: 16px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <div style="display: flex; gap: 14px;">
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">Rule: No SELECT *</div>
# MAGIC       <div style="padding: 12px 14px; background: #f8fafc; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         <div style="margin-bottom: 6px;">Pick dimensions and measures explicitly.</div>
# MAGIC         <div style="background: #FFF7EC; border: 1px solid #FF9800; border-radius: 4px; padding: 6px 10px; font-size: 14px;"><code style="font-size: 14px;">SELECT *</code> errors because columns are split into dimensions and measures.</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 1; border: 2px solid #FE3722; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #FE3722; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">Rule: Wrap measures in MEASURE()</div>
# MAGIC       <div style="padding: 12px 14px; background: #FFF8F7; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         <div style="margin-bottom: 6px;"><code style="font-size: 15px;">MEASURE(total_revenue)</code> not <code style="font-size: 15px;">total_revenue</code></div>
# MAGIC         <div style="background: #FFF7EC; border: 1px solid #FF9800; border-radius: 4px; padding: 6px 10px; font-size: 14px;">Bare measure names error. Measures carry built-in aggregation logic.</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC     <div style="flex: 1; border: 2px solid #00A972; border-radius: 10px; overflow: hidden;">
# MAGIC       <div style="background: #00A972; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; text-align: center;">Tip: GROUP BY ALL</div>
# MAGIC       <div style="padding: 12px 14px; background: #F0FAF5; font-size: 15px; color: #3d5a65; line-height: 1.5;">
# MAGIC         <div style="margin-bottom: 6px;">When your SELECT includes dimensions, you need a GROUP BY. <code style="font-size: 15px;">GROUP BY ALL</code> is the shorthand.</div>
# MAGIC         <div style="font-size: 14px; color: #5E7077;">If you only select measures (no dimensions), skip GROUP BY entirely to get grand totals.</div>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC The first query uses all three. Run it.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   category,
# MAGIC   MEASURE(total_revenue) AS revenue,
# MAGIC   MEASURE(order_count)   AS orders
# MAGIC FROM vw_product_metrics
# MAGIC GROUP BY ALL
# MAGIC ORDER BY revenue DESC;

# COMMAND ----------

# MAGIC %md
# MAGIC You should see five rows, one per product category, sorted by revenue. The `MEASURE()` function evaluates each measure's stored aggregation against the current grouping. `GROUP BY ALL` tells Databricks to group by every non-measure column in the `SELECT` list, which saves you from listing them again.
# MAGIC
# MAGIC ### One more query: aggregate across everything
# MAGIC
# MAGIC If you omit the dimension and just select measures, you get one row with the totals:

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   MEASURE(total_revenue) AS total_revenue,
# MAGIC   MEASURE(order_count)   AS order_count
# MAGIC FROM vw_product_metrics;

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC One row, two totals. Same metric view, different question, same definitions of `total_revenue` and `order_count`.
# MAGIC
# MAGIC ### Use Genie Code to explain a query
# MAGIC
# MAGIC Genie Code isn't just for writing SQL, it's good at *explaining* it. The inline box can't read an existing query, so use the **sidebar** for this one.
# MAGIC
# MAGIC <div style="width: 100%; margin: 12px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 16px;">
# MAGIC   <div style="display: flex; gap: 0; align-items: stretch;">
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">1</span> Select the query cell
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1; color: #3d5a65; line-height: 1.6;">Click the all-totals query cell above to select it</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 40px; display: flex; align-items: center; justify-content: center; font-size: 24px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">2</span> Open sidebar Genie
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1; color: #3d5a65; line-height: 1.6;">Click the <strong>Genie / Assistant</strong> icon on the right edge of the workspace</div>
# MAGIC     </div>
# MAGIC     <div style="flex: 0 0 40px; display: flex; align-items: center; justify-content: center; font-size: 24px; color: #1B5162;">&#x2192;</div>
# MAGIC     <div style="flex: 1.4; border: 2px solid #1B5162; border-radius: 10px; overflow: hidden; display: flex; flex-direction: column;">
# MAGIC       <div style="background: #1B5162; color: #fff; padding: 10px 14px; font-size: 16px; font-weight: 700; display: flex; align-items: center; gap: 8px;">
# MAGIC         <span style="background: rgba(255,255,255,0.2); border-radius: 50%; width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">3</span> Ask this
# MAGIC       </div>
# MAGIC       <div style="padding: 14px; background: #f8fafc; flex: 1;">
# MAGIC         <div id="genie-prompt-10" style="background: #fff; border: 1.5px solid #DCE0E2; border-radius: 8px; padding: 12px 14px; color: #3d5a65; line-height: 1.5; font-style: italic;">Explain what this query does and why the measures are wrapped in MEASURE().</div>
# MAGIC         <button onclick="var t=document.getElementById('genie-prompt-10').textContent,a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.left='-9999px';document.body.appendChild(a);a.select();document.execCommand('copy');document.body.removeChild(a);this.textContent='Copied!';this.style.background='#00A972';this.style.borderColor='#00A972';var b=this;setTimeout(function(){b.textContent='Copy prompt';b.style.background='#1B5162';b.style.borderColor='#1B5162'},1500)" style="margin-top: 10px; background: #1B5162; color: #fff; border: 2px solid #1B5162; border-radius: 6px; padding: 6px 18px; font-size: 16px; font-weight: 600; cursor: pointer;">Copy prompt</button>
# MAGIC       </div>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC Genie should explain that `MEASURE()` evaluates each measure's stored aggregation from the metric view definition, and that without a `GROUP BY`, the measures aggregate across all rows to produce grand totals. Asking AI to explain unfamiliar syntax is a fast way to build understanding when you're new to a feature.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## 7. The key takeaway: one definition, changed in one place
# MAGIC
# MAGIC <div style="border-left: 5px solid #FE3722; background: #FDEBE8; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <strong style="display:block; color:#C62828; font-size:1.08em; margin-bottom:8px;">This is the whole point of a metric view</strong>
# MAGIC <div style="color:#333;">
# MAGIC The measure <code>total_revenue</code> is defined <strong>once</strong>, as <code>SUM(source.total_amount)</code>, inside the metric view's YAML. Every consumer: the SQL Editor, dashboards, Genie Agents, alerts, Power BI evaluates that same definition. There is no second place where "revenue" is defined, so two teams can't end up with two different revenue numbers.
# MAGIC <br><br>
# MAGIC If the business later redefines revenue (say, revenue should be net of tax), you change the <code>expr:</code> in <strong>one place</strong> and every query, dashboard, and report picks it up automatically. You'll do exactly that in the next step.
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 14px 18px; border-radius: 4px; margin: 12px 0; font-size: 15px; color: #333; line-height: 1.6;">
# MAGIC   <strong style="color: #1565c0; font-size: 16px;">Try it (optional)</strong>
# MAGIC   <ol style="margin: 8px 0 0 0; padding-left: 20px;">
# MAGIC     <li>In the Catalog Explorer editor, change the <code style="font-size: 15px;">total_revenue</code> measure's <code style="font-size: 15px;">expr:</code> from <code style="font-size: 15px;">SUM(source.total_amount)</code> to <code style="font-size: 15px;">ROUND(SUM(source.total_amount), 0)</code> and <strong>Save</strong>.</li>
# MAGIC     <li>Re-run the category query above. The revenue values update with <strong>no change to the query itself</strong>.</li>
# MAGIC     <li>Change it back afterward if you like.</li>
# MAGIC   </ol>
# MAGIC   <p style="margin: 8px 0 0 0;">This is what "single source of truth" means in practice.</p>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## What you did in this lesson
# MAGIC
# MAGIC <div style="border-left: 4px solid #4caf50; background: #e8f5e9; padding: 14px 18px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="color:#333;">
# MAGIC You learned how to read and query a metric view:
# MAGIC
# MAGIC | Step | What you did |
# MAGIC |---|---|
# MAGIC | Understood why metric views matter | One definition, many consumers (SQL Editor, dashboards, Genie Agents, alerts, external BI), no duplicate metric logic |
# MAGIC | Opened the metric view in Catalog Explorer | Toured the Overview, Details, and Lineage tabs |
# MAGIC | Explored the low-code UI | Clicked the join (lineage context), measures (expr, comments, synonyms), and dimensions |
# MAGIC | Walked through the YAML | <code>version</code>, <code>source</code>, <code>joins</code>, <code>dimensions</code>, <code>measures</code> |
# MAGIC | Queried the metric view | Three rules: no <code>SELECT *</code>, wrap measures in <code>MEASURE()</code>, use <code>GROUP BY ALL</code> |
# MAGIC | Used Genie Code | To explain a metric-view query |
# MAGIC
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC &copy; <span id="dbx-year"></span> Databricks, Inc. All rights reserved.
# MAGIC Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>
# MAGIC <script>
# MAGIC   document.getElementById("dbx-year").textContent = new Date().getFullYear();
# MAGIC </script>