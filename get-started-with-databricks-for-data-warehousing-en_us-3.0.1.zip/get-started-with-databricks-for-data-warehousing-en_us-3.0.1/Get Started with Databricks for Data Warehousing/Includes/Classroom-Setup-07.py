# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M07 (lab) adds the 2025 files to orders_bronze. Ensure the 2024 base
# that the lab builds on already exists.
ensure_orders_bronze_2024()
