# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M05 (lab) optimizes the products table. Ensure source tables exist.
ensure_source_dimensions()
