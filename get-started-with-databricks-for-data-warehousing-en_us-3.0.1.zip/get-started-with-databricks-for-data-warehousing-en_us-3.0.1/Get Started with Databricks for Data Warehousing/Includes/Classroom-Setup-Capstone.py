# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# The Capstone builds its own reporting table and metric view on top of the
# star schema, so ensure the full star schema (fact_orders + all dimensions)
# exists first. This backfills the whole chain from the raw CSVs if a learner
# opens the Capstone without having run the earlier lessons.
ensure_star_schema()

# This notebook is commonly run more than once. Drop the artifacts the
# Capstone creates so every run starts from a clean, repeatable state and the
# CREATE statements below never collide with a partial earlier attempt.
spark.sql("DROP TABLE IF EXISTS store_quarterly_revenue")
spark.sql("DROP VIEW IF EXISTS vw_quarterly_metrics")

print("Environment ready: star schema in place; capstone artifacts reset.")