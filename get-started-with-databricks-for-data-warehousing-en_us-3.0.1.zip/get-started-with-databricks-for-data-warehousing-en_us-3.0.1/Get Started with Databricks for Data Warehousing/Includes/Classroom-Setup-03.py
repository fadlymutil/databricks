# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M03 (lab) queries the source tables. Ensure they exist.
ensure_source_dimensions()
