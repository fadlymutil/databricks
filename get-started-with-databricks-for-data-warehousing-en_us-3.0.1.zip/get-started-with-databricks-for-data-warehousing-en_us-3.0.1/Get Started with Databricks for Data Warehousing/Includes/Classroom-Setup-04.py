# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M04 tunes the source tables (products/customers). Ensure they exist.
ensure_source_dimensions()
