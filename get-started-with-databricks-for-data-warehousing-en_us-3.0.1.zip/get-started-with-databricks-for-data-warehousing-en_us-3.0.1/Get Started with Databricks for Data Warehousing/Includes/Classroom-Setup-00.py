# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M00 is the authoritative environment setup. Classroom-Setup-Common has
# already created the catalog, schema, and volume and staged all CSV files.
# Here we build the three base source tables the rest of the course uses.
# (Order files stay in the volume; M06 loads them with Auto Loader.)
ensure_source_dimensions()

print("Environment ready: catalog, schema, volume, staged CSVs, and base tables (customers, products, stores).")
