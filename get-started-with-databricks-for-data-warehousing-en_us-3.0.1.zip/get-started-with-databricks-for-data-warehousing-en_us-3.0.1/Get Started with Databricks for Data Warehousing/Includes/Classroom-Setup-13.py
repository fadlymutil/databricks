# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M13 (lab) clones fact_orders into fact_orders_slow. Ensure the full star
# schema first.
ensure_star_schema()

# This lab is commonly run more than once. Reset the lab's working table and
# clear cached query results so each run starts from the same unoptimized
# baseline and the Query Profile timings are honest.
spark.sql("DROP TABLE IF EXISTS fact_orders_slow")
try:
    spark.sql("CLEAR CACHE")
except Exception:
    pass
