# Databricks notebook source
# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

# MAGIC %run ./state_helpers

# COMMAND ----------

# M12 clones fact_orders into fact_orders_unoptimized for the Query Profile
# demo. Ensure the full star schema first.
ensure_star_schema()

# This notebook is commonly run more than once (a dry run before class, then
# live). Reset the demo's working table and clear cached query results so each
# run starts from the same unoptimized baseline and Query Profile timings are
# honest.
spark.sql("DROP TABLE IF EXISTS fact_orders_unoptimized")
try:
    spark.sql("CLEAR CACHE")
except Exception:
    pass
